var dir_615c8c0bae8a2a40e2d745671a67fb81 =
[
    [ "libs", "dir_6ab501ba856d951167c86be124fb37d6.html", "dir_6ab501ba856d951167c86be124fb37d6" ],
    [ "vs.c", "vs_8c.html", "vs_8c" ],
    [ "vs.h", "vs_8h.html", "vs_8h" ]
];