var dir_a26c037cbd8dc8bd98ac6fb20a01f523 =
[
    [ "sender.c", "sender_8c.html", "sender_8c" ],
    [ "sender.h", "sender_8h.html", "sender_8h" ]
];