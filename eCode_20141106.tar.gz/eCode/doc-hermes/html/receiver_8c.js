var receiver_8c =
[
    [ "configuration", "structconfiguration.html", "structconfiguration" ],
    [ "BUFFSIZE", "receiver_8c.html#a39912bfe2a55f30e269196f9141d845d", null ],
    [ "MATCH", "receiver_8c.html#af06fecdfaf06dfc4fdb5dc5b386dbfe3", null ],
    [ "log2file", "receiver_8c.html#a7e3569c035b22644b759c9a7430ae44e", null ],
    [ "main", "receiver_8c.html#a0ddf1224851353fc92bfbff6f499fa97", null ]
];