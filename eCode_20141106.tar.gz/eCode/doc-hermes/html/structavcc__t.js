var structavcc__t =
[
    [ "AVCLevelIndication", "structavcc__t.html#aad7f2f92d70916e3dffe21e8e8ba0b60", null ],
    [ "AVCProfileIndication", "structavcc__t.html#ab4b505107336b37494bd85464806219d", null ],
    [ "configurationVersion", "structavcc__t.html#aff8851964be7f04f5d64fa0df8447909", null ],
    [ "lengthSizeMinusOne", "structavcc__t.html#ab6f073a2a0ef7bfc4c6742a30ebb60a4", null ],
    [ "numOfPictureParameterSets", "structavcc__t.html#a0e8593343a472b711a4e0ffcf211701a", null ],
    [ "numOfSequenceParameterSets", "structavcc__t.html#a3aa513264026e41fd2f686867a2bec1e", null ],
    [ "pps_table", "structavcc__t.html#ad0c4c0a763dab5e5c78f02c4a0097c46", null ],
    [ "profile_compatibility", "structavcc__t.html#ad5e7d4f6f93c0ea64ae4097ecb053a96", null ],
    [ "sps_table", "structavcc__t.html#a36b910cb644497d2a601a35d4ea899bc", null ]
];