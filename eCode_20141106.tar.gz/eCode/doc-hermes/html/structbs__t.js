var structbs__t =
[
    [ "bits_left", "structbs__t.html#a3b832bc0d6feb1acd7a47c805b67c2b4", null ],
    [ "end", "structbs__t.html#ae56df50a18c6b76fecbe54e636618877", null ],
    [ "p", "structbs__t.html#a6a3b41978cc33dbbe9b91a57d6aca0dd", null ],
    [ "start", "structbs__t.html#a3273aa61196e742ddd475518861ca2d3", null ]
];