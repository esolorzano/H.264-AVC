var structconfig__t =
[
    [ "debug", "structconfig__t.html#aa31c9e8e15dd4c608dcee7385dfd629c", null ],
    [ "debugtcpinfo", "structconfig__t.html#a33b2cd28e15ae5c054f985756f7923eb", null ],
    [ "extension", "structconfig__t.html#ad4e6177784b92389f7ac2dbeacea79e3", null ],
    [ "inFile", "structconfig__t.html#abcadbc6945fd0b04db2b1bcc0ae4b756", null ],
    [ "mediadesc", "structconfig__t.html#a82d0f4464a7520d19aced3feda7726a5", null ],
    [ "numfiles", "structconfig__t.html#a1d45a0844e4c7db76a29d85d267c85d2", null ],
    [ "path", "structconfig__t.html#af57220a575ba0ca02d016c234f7ace6a", null ],
    [ "port", "structconfig__t.html#ac997ada4ac47a86ad2ca79564089e888", null ],
    [ "prefixQL1", "structconfig__t.html#a752c957f1a87fcac3d2efd715d15fc01", null ],
    [ "prefixQL2", "structconfig__t.html#a3fa21590e2dc80b69a759a6cc3409996", null ],
    [ "prefixQL3", "structconfig__t.html#a629ea2668cf2318c0e8b0df9ac4582e0", null ],
    [ "prefixQL4", "structconfig__t.html#aabc16fa3a5e9605d174e51e318e71b51", null ]
];