var structconfig__vs__t =
[
    [ "debug", "structconfig__vs__t.html#a28af64eb88afff984f67bbbbacd24e06", null ],
    [ "fileprefix", "structconfig__vs__t.html#a5feb7e2e8c419ae4d24b4b2d2b5924f5", null ],
    [ "inFile", "structconfig__vs__t.html#ab9395e06f1e1051f6f8ff1b7b382b688", null ],
    [ "mediadesc", "structconfig__vs__t.html#a9a8c1f0ac05d2a830609511ef5a18dee", null ],
    [ "nsegundos", "structconfig__vs__t.html#adf6dfeac80614bd3566d61a463403a55", null ],
    [ "outpath", "structconfig__vs__t.html#a39320d089f671c2897c5d1acfa814816", null ],
    [ "sourceH264", "structconfig__vs__t.html#a859e659da877bc28c3fbfed0ad4aca7f", null ]
];