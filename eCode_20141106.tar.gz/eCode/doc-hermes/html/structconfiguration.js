var structconfiguration =
[
    [ "datalog", "structconfiguration.html#a47f1f8241c229a4cc0ed9ccd61f23518", null ],
    [ "debug", "structconfiguration.html#a0c44a1d5d7a21dba28d6308ef6b25329", null ],
    [ "inFile", "structconfiguration.html#af91cc40779b4b255fe52ec6f13fadc41", null ],
    [ "ip", "structconfiguration.html#ae67fc80361870af7eec86894e4efb9a4", null ],
    [ "outFile", "structconfiguration.html#a78b0133bb154dd5eb99228e61e06ef5d", null ],
    [ "port", "structconfiguration.html#a3f66b5ac4a31c99fca0743748e14efd9", null ]
];