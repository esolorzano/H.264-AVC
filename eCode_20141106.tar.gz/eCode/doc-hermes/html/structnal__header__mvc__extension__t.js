var structnal__header__mvc__extension__t =
[
    [ "anchor_pic_flag", "structnal__header__mvc__extension__t.html#a846091719c466bfb6569ca55ca0e1131", null ],
    [ "inter_view_flag", "structnal__header__mvc__extension__t.html#a0f78296bf1fe93b438110ac6d53d5eab", null ],
    [ "non_idr_flag", "structnal__header__mvc__extension__t.html#a907ca5582c49247fc705a9a5259fc338", null ],
    [ "priority_id", "structnal__header__mvc__extension__t.html#a2de78d53313c8a61698d0cd37de0af8e", null ],
    [ "reserved_one_bit", "structnal__header__mvc__extension__t.html#a374c4cff995bcbcb3d3d149796428d21", null ],
    [ "temporal_id", "structnal__header__mvc__extension__t.html#a005c0575fbb95707a6533540186c51ed", null ],
    [ "view_id", "structnal__header__mvc__extension__t.html#abc4bbb488a6c61af612135344470dda1", null ]
];