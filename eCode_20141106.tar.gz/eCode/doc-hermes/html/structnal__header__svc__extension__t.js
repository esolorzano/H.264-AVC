var structnal__header__svc__extension__t =
[
    [ "dependency_id", "structnal__header__svc__extension__t.html#ab476e3de63288b32bd9bcc9d7deac408", null ],
    [ "discardable_flag", "structnal__header__svc__extension__t.html#a3810a05cbda889344e27a515e4c13c62", null ],
    [ "idr_flag", "structnal__header__svc__extension__t.html#a1186efb3ba18fc4cdb16ef78076032d4", null ],
    [ "no_inter_layer_pred_flag", "structnal__header__svc__extension__t.html#afbabd7025d768a580814aad8ca7a8ec0", null ],
    [ "output_flag", "structnal__header__svc__extension__t.html#a5f694a4b87d4615be55e8205b7dcc345", null ],
    [ "priority_id", "structnal__header__svc__extension__t.html#a0223019182a02784371ceaff87552601", null ],
    [ "quality_id", "structnal__header__svc__extension__t.html#aecf5ebeddfa71d02201b246c532401ec", null ],
    [ "reserved_three_2bits", "structnal__header__svc__extension__t.html#aef11cb288c7f84d20c77bed73eab9e4d", null ],
    [ "temporal_id", "structnal__header__svc__extension__t.html#ada2126a30673325d3b63fd0cf33df104", null ],
    [ "use_ref_base_pic_flag", "structnal__header__svc__extension__t.html#a3b4006afd90d063acf0ecbcd5561539a", null ]
];