var structnal__t =
[
    [ "forbidden_zero_bit", "structnal__t.html#a37e8529ea6fb6dcc091826bf8286c3ae", null ],
    [ "mvc_header_ext", "structnal__t.html#ad1be344e3b5bb33a848d2a38f5e822a2", null ],
    [ "nal_ref_idc", "structnal__t.html#a9a0593bc689f4f7ff2edec2dd4c18217", null ],
    [ "nal_unit_type", "structnal__t.html#a7d797a65b9ebf181e0ee4ecd88d54882", null ],
    [ "nalUnitHeaderBytes", "structnal__t.html#a290f6ee834b473fd18333e2dfdf1a4ce", null ],
    [ "parsed", "structnal__t.html#a8b692fc3c035206e9feba370a1a6e09f", null ],
    [ "sizeof_parsed", "structnal__t.html#a8beaa4797eb8ed7faa1a2ce94239a493", null ],
    [ "svc_extension_flag", "structnal__t.html#a527c6fa010b96bbf111a5873c4201616", null ],
    [ "svc_header_ext", "structnal__t.html#a89fa111cb51d3efaa8a66412e6af33e8", null ]
];