var structpicture__timestamp__t =
[
    [ "clock_timestamp_flag", "structpicture__timestamp__t.html#a1fa8857a705e1ecece383412940c8ac1", null ],
    [ "cnt_dropped_flag", "structpicture__timestamp__t.html#ac93acb714de23a06dedf15a5b83cf5b9", null ],
    [ "counting_type", "structpicture__timestamp__t.html#ae1bfc7853d9457b9b97ce60ce108efa4", null ],
    [ "ct_type", "structpicture__timestamp__t.html#a2896efa488f49be189bf547e8eedabed", null ],
    [ "discontinuity_flag", "structpicture__timestamp__t.html#af030b9292a1fb4a58c1e92a28cee96fb", null ],
    [ "full_timestamp_flag", "structpicture__timestamp__t.html#afcb2a7cf0208d3adc7388fd9d874dca0", null ],
    [ "hours_flag", "structpicture__timestamp__t.html#ae43d33e3eeae93a21ca293a413b074c7", null ],
    [ "hours_value", "structpicture__timestamp__t.html#ae941eb59937aa9f05431086b8368da95", null ],
    [ "minutes_flag", "structpicture__timestamp__t.html#ab682335ea853af0cb52a097536458d72", null ],
    [ "minutes_value", "structpicture__timestamp__t.html#a4e9db2a5fcaf4348819c59c5dd1af42c", null ],
    [ "n_frames", "structpicture__timestamp__t.html#a389fcec4122a649997774813735297bd", null ],
    [ "nuit_field_based_flag", "structpicture__timestamp__t.html#a32c4bee7c02cc4f1d44f11abcd3f204f", null ],
    [ "seconds_flag", "structpicture__timestamp__t.html#a5e035fcd7cc6abe5eac346b64ec5e257", null ],
    [ "seconds_value", "structpicture__timestamp__t.html#adc2258fb3f32ec8d8aa5be8f4e1b4309", null ],
    [ "time_offset", "structpicture__timestamp__t.html#adda485cac8cb9c212cfec43c0f3dbc2a", null ]
];