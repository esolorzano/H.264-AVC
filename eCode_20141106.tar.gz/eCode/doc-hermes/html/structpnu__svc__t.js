var structpnu__svc__t =
[
    [ "adaptive_ref_base_pic_marking_mode_flag", "structpnu__svc__t.html#a85ebb01d7e81bbf1c5c945a6fb1a8b10", null ],
    [ "additional_prefix_nal_unit_extension_data_flag", "structpnu__svc__t.html#a392a845d9f7e435edefb52b01b766d9c", null ],
    [ "additional_prefix_nal_unit_extension_flag", "structpnu__svc__t.html#af508de109ecb88243d8e15f360902f90", null ],
    [ "dec_ref_base_pic_mkg", "structpnu__svc__t.html#a497ea3b6ef6ad62670ac4742dd0f028c", null ],
    [ "difference_of_base_pic_nums_minus1", "structpnu__svc__t.html#a8b631efa5c76cc3e9bfd8de24dfb681f", null ],
    [ "long_term_base_pic_num", "structpnu__svc__t.html#a81f859068373166ff872b0de939760fa", null ],
    [ "memory_management_base_control_operation", "structpnu__svc__t.html#ab069f8b344eefb99b0cdcdb5cc0e7ec9", null ],
    [ "store_ref_base_pic_flag", "structpnu__svc__t.html#a62cfa04c7d5a5078f9c96629c1f0d2ff", null ]
];