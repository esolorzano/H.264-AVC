var structsei__buffering__t =
[
    [ "_is_initialized", "structsei__buffering__t.html#a01d79cc711a55787d8d753483022c853", null ],
    [ "initial_cpb_delay_offset", "structsei__buffering__t.html#a9c4023701f863e5ebe3b7b4c59316d97", null ],
    [ "initial_cpb_removal_delay", "structsei__buffering__t.html#ac86b5b4b2f20a612c56a09789834046f", null ],
    [ "sps_id", "structsei__buffering__t.html#a85defef1543bd880610aae58c0f80a2d", null ]
];