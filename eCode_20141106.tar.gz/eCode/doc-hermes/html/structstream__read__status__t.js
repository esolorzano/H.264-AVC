var structstream__read__status__t =
[
    [ "buf", "structstream__read__status__t.html#a18091e498f6bb4683b6ad77d52dc92e0", null ],
    [ "first_load", "structstream__read__status__t.html#afd6d8ee367d7cabff7c97ab3710b1677", null ],
    [ "fs", "structstream__read__status__t.html#a9299e513cfc7494580b797611520364b", null ],
    [ "GOPcounter", "structstream__read__status__t.html#ac3a4d3c0c3f1cd32a32e8d5657b36844", null ],
    [ "h", "structstream__read__status__t.html#aae3b6917e13dda0b2793f36497ff2879", null ],
    [ "meanGOPsize", "structstream__read__status__t.html#afd38fa025751ae07d0711cd84ade8f85", null ],
    [ "nal_end", "structstream__read__status__t.html#aaec38c9794f6aab03bdc2974cf41f279", null ],
    [ "nal_start", "structstream__read__status__t.html#afdef54328c3a5d9b4b8717f626f9559d", null ],
    [ "nextGOPHeaderBuffer", "structstream__read__status__t.html#a10a0db882091ba0e441cc78071e385ae", null ],
    [ "nextGOPHeaderSize", "structstream__read__status__t.html#ade3220a37d561183c5fb21d1f346beef", null ],
    [ "nu_index", "structstream__read__status__t.html#a04be6908011fa282e29370717d795418", null ],
    [ "off", "structstream__read__status__t.html#aca085437078eb35fc9eb30557074bf1f", null ],
    [ "p", "structstream__read__status__t.html#a47869efc7831a844c575eff9c8f5cd9f", null ],
    [ "p_dump", "structstream__read__status__t.html#a0fa40dad04c8ed76a7e8f1540fcaa9f8", null ],
    [ "p_slice_I_data", "structstream__read__status__t.html#aa78fe4dac8d0f4c4c731965940632516", null ],
    [ "p_slice_I_size", "structstream__read__status__t.html#a93d4d98fb2ad63a75638860f552bd619", null ],
    [ "rsz", "structstream__read__status__t.html#a793cb3c473b070e38de13519731fc95a", null ],
    [ "sz", "structstream__read__status__t.html#af2220bfd942dee07d0083018b9420d34", null ]
];