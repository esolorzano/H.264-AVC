var structtimes__t =
[
    [ "tvBegin", "structtimes__t.html#adfe6e33c73af23e444755ec62ac091bc", null ],
    [ "tvDiff", "structtimes__t.html#a024e7a0ba51f3e06dd5baafb4e6587fa", null ],
    [ "tvEnd", "structtimes__t.html#a29152783581826b433a0f8d177ce761e", null ]
];