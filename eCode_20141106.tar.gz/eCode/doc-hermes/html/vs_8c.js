var vs_8c =
[
    [ "MATCH", "vs_8c.html#af06fecdfaf06dfc4fdb5dc5b386dbfe3", null ],
    [ "createH264file", "vs_8c.html#a7124614413b6831c0c6ef85fb1a90b7c", null ],
    [ "createMediaDescriptionFile", "vs_8c.html#a22b1ba5a7038fcb8cff2a595ad82325a", null ],
    [ "itoa", "vs_8c.html#a94183e8d9092e97cadb569ed22ffe103", null ],
    [ "main", "vs_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "recordBitrate", "vs_8c.html#aa9c9acf54edb799a3c317fe220ae4d90", null ],
    [ "setdown", "vs_8c.html#aaa1d3071d2cc322abf8e5c5a4e10bd82", null ],
    [ "setup", "vs_8c.html#a5d5c917f3d856546fbe2d59acdda3632", null ],
    [ "testSaveLocal", "vs_8c.html#a309c4a26341f698e5e74addd68d035eb", null ]
];