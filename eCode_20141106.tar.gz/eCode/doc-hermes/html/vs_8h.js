var vs_8h =
[
    [ "config_vs_t", "structconfig__vs__t.html", "structconfig__vs__t" ],
    [ "GOPBUFFER_SIZE", "vs_8h.html#ad58c1deca5df719e3a68067d3e5c9353", null ],
    [ "GOPSinSECOND", "vs_8h.html#ae46d8967883cd52a9082df7c521e9cf7", null ],
    [ "MEANGOP_SIZE", "vs_8h.html#a2ec74570fa9a98783d6a07c2bcc00400", null ],
    [ "STREAMSEG_SIZE", "vs_8h.html#a8f67bee74d90d6604fa2d44e32832cc8", null ],
    [ "createH264file", "vs_8h.html#a7124614413b6831c0c6ef85fb1a90b7c", null ],
    [ "createMediaDescriptionFile", "vs_8h.html#a22b1ba5a7038fcb8cff2a595ad82325a", null ],
    [ "itoa", "vs_8h.html#a94183e8d9092e97cadb569ed22ffe103", null ],
    [ "recordBitrate", "vs_8h.html#aa9c9acf54edb799a3c317fe220ae4d90", null ],
    [ "setdown", "vs_8h.html#aaa1d3071d2cc322abf8e5c5a4e10bd82", null ],
    [ "setup", "vs_8h.html#a5d5c917f3d856546fbe2d59acdda3632", null ],
    [ "testSaveLocal", "vs_8h.html#a309c4a26341f698e5e74addd68d035eb", null ]
];