
//Selector
#define S_GOPBUFFER_SIZE		128*1024	//longitud buffer temporal para GOPs
#define S_STREAMSEG_SIZE		2*1024*1024 //longitud buffer temporal para streams
#define S_GOPS2SEGMENT			30 //numero de GOPs en un segmento
#define S_NUMSOURCES				4 //numero de ficheros stream H264

//Controller
#define C_DATABLOCK_SIZE		S_STREAMSEG_SIZE //longitud buffer para streams

//Transmitter
#define T_DATAPARTS					20 //numero de parte envio contenido buffer
#define T_TXDATABUF_SIZE		S_STREAMSEG_SIZE //longitud buffer para streams

