/**
 *  @author	Edwin Solorzano <solorzano.em@gmail.com>	
 *  @file	receiver.c
 *  @data 2013-10-07
 *  @brief	Performs data flow request to the transmitter.
 *  @version  0.2.0
 *  
 *  @updates
 *   0.2.0
 *   - Calcula e imprime en pantalla el throughput.
 *   - Compatible con al ultima versión de ../sender/sender.c
 *  
 *   0.1.1
 *   - ya no se recibe la longitud de datos a recibir del Transmitter.
 *   - recibir hasta que en TRANSMITTER agote los datos.
 *   - compatible con la versión 0.1.2 de transmitter.c
 *    
 *   0.1.0
 *   - version inicial, compatible con la versión 0.1.1 de transmitter.c
 */

#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h> 

#include <time.h>
#include <math.h>

#include "../common/common.h" //getPeriodTime(), calculateRate() & timeval_subtract()
#include "../common/ini.h" //init config file load

#define BUFFSIZE 4*1024*1024

typedef struct
{    
    /*@{*/
    int port;
    const char* ip;
    const char* outFile;
    const char* inFile;
    int debug;
    int datalog;
    /*@}*/
    
    // al agregar un parámetro aqui tambien se debe actualizar la funcion handler()
} configuration; 

static int handler(void* user, const char* section, const char* name, const char* value);
void log2file(int n, int rate);
/*----------------------------------------------------------------------------*/
//******************************* MAIN **************************************
/**
 *  @brief Programa principal
 *  
 */
int main(int argc, char *argv[])
{
  
  configuration config;
  FILE* fout = 0; 
  int sockfd = 0, n = 0;
  uint8_t* recvBuff = (uint8_t*)malloc(BUFFSIZE);
  struct sockaddr_in serv_addr; 
  
  char type;
  long counter;
  
  times_t times;
  int rate;
  
  char * cwd;
  cwd = getcwd (0, 0);
  
  /*== Carga de configuracion ==*/
  if (ini_parse("file.ini", handler, &config) < 0) {
    printf("No se pudo cargar la configuration de 'file.ini'\n");
    return 1;
  }
  
  if(config.debug){
    printf("config params:\n");
    printf("\tConfig file: %s/%s\n",cwd,config.inFile);
    printf("\toutFile    : %s\n",config.outFile);
    printf("\tip server  : %s\n",config.ip);
    printf("\tport       : %d\n",config.port);
    printf("\tdebug: %d\n\n",config.debug);
  }    

  /*== Creación de la conexion TCP ==*/
  memset(recvBuff, '0',BUFFSIZE);
  if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
  {
      printf("\n Error : Could not create socket \n");
      return 1;
  } 

  memset(&serv_addr, '0', sizeof(serv_addr)); 

  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(config.port); 

  if(inet_pton(AF_INET, config.ip, &serv_addr.sin_addr)<=0)
  {
      printf("\n inet_pton error occured\n");
      return 1;
  } 

  if( connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
  {
     printf("\n Error : Connect Failed \n");
     return 1;
  } 

  /*== Creación fichero de salida ==*/
  fout = fopen(config.outFile, "wb");
  
  /*== Recepción de Datos ==*/
  
  /* .. Lectura de Datos .. */
  counter = 0;
  do{
    getPeriodTime(&times,'b');
    n = read(sockfd,recvBuff,BUFFSIZE);        
    getPeriodTime(&times,'e');
    rate = calculateRate(n,times.tvDiff)/1000; //Kbps
    
    fwrite(recvBuff,1,n,fout);
    counter += n;
    if(config.debug && n>0) printf("cnt: %10li B|n: %9d B|br: %10d kbps\n",counter,n,rate); //TEST
    if(config.datalog) log2file(n,rate);
  }while(n>0);
  fclose(fout);
  close(sockfd);
  
  if(config.debug) printf("\ntotal recibido: %li bytes\n",counter); //TEST  
  
  if(n < 0) printf("\n Read error \n");

  return 0;
}

/*----------------------------------------------------------------------------*/

/**
 *   @brief Permite cargar los valores del fichero de inicialización
 */

static int handler(void* user, const char* section, const char* name, const char* value)
{
    configuration* pconfig = (configuration*)user;

    #define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
    if (MATCH("files", "inFile")) {
        pconfig->inFile = strdup(value);
    } else if (MATCH("files", "outFile")) {
        pconfig->outFile = strdup(value);
    } else if (MATCH("server", "port")) {
        pconfig->port = atoi(value);
    } else if (MATCH("server", "ip")) {
        pconfig->ip = strdup(value);
    } else if (MATCH("tracer", "debug")) {
        pconfig->debug = atoi(value);
    } else if (MATCH("tracer", "datalog")) {
        pconfig->datalog = atoi(value);
    } else {
        return 0;  /* seccion/nombre desconocidos, error */
    }
    
    
    return 1;
}

/**
 *  @brief registra en el fichero log.txt los parametros n y rate.
 *  
 *  @param [in] n numero de bytes.
 *  @param [in] rate bitrate
 */
void log2file(int n, int rate){
  time_t rawtime;
  struct tm * timeinfo;
  char buffer [80];
  
  time (&rawtime);
  timeinfo = localtime (&rawtime);
  strftime(buffer,80,"%Y-%m-%d %H:%M:%S",timeinfo);
  
  FILE* fd = fopen("log.txt","a+");
  fprintf(fd,"%s - recibidos: %10d bytes, rate: %10d kbps\n",buffer,n,rate);
  fclose(fd);
}
