/**
 *  @author Edwin Solorzano <solorzano.em@gmail.com>
 *  @file sender.c
 *  @date 2014-06-28
 *  @version 0.1.5
 *  @brief Lee y envia streams H264/AVC adaptando la calidad del video a la
 *  capacidad del medio, medido a traves del throughput.
 */

#include "../common/common.h"
#include "../common/ini.h" //init config file load
#include "sender.h"

/*----------------------------------------------------------------------------*/
/**
 *  @brief Programa principal
 */
int main(){

	//fclose(fopen("salida_local.264","w+")); //TEST

  /*== Carga de configuracion ==*/
  config_t config;
	if(loadConfiguration(&config)){ return 1; }
	if(loadMediaDescription(&config)){ return 1; }

  //debug fuente utilizada
  if(config.debug){
    fclose(fopen("bitrate_qlevel.csv","w+"));
  }
  
	//debug tcp_info data
	if(config.debugtcpinfo){
		getPeriodTime(&tstats,'b'); //times_t tstats definido en sender.h
		fclose(fopen("stats.txt","w+"));
		int r = system("echo 'time last_data_sent last_data_recv snd_cwnd snd_ssthresh rcv_ssthresh rtt rttvar unacked sacked lost retrans fackets' > stats.txt");
	}
	
	/*socket TCP setup*/
	int listenfd = setupSocket(config.port);

	int fileNumber = config.numfiles;
	
	while(1){
		int connfd = accept(listenfd, (struct sockaddr*)NULL, NULL);
		printf("nuevo cliente...\n");
		sendData(connfd, config);
		close(connfd);
		printf(".............- DONE -.............\n\n");
	}


	return 0;
}

/*----------------------------------------------------------------------------*/
/**
 *  @brief Envia los chunks de un stream H264/AVC a un cliente TCP/IP.
 *  
 *  @param [in] connfd descriptor de la conexion
 *  @param [in] config estructura que contiene la configuracion de la aplicacion.
 */
void sendData(int connfd, config_t config){

	times_t times;	
	long throughput = 0;
	long throughput_last = 0;	
	
	int buffer_size = READBUFFER_SIZE;
	uint8_t* buffer = (uint8_t*)calloc(buffer_size,sizeof(uint8_t));
	char prefix[20] = {0}; strcpy(prefix,config.prefixQL1);
	int qlevel = 1;

	for(int i=1;i <= config.numfiles; i++){

		bzero(buffer,READBUFFER_SIZE);
		char filename[200] = {0};
		createFilename(config, prefix, i, filename);

		FILE* fd = fopen(filename,"rb");
		int n = fread(buffer,1,buffer_size,fd);
		//testSaveLocal(buffer,n); //TEST
		fclose(fd);

		getPeriodTime(&times,'b');
    int n_tx = 0;
    int counter = 1;
    long throughput_acum = 0;
    
    if( n > MSS ){
      do{
        // getPeriodTime(&times,'b'); //TEST micromedida
        n_tx += write(connfd, buffer + n_tx, MSS);
        // getPeriodTime(&times,'e'); //TEST micromedida
        // throughput = calculateRate(n_tx,times.tvDiff)/1000; //Kbps //TEST micromedida
        // if(config.debug) recordQlevel(i, throughput, qlevel); //TEST micromedida
        // throughput_acum += throughput; //TEST micromedida
        if(config.debugtcpinfo)recordTCPinfo(connfd);
        // counter++; //TEST micromedida
      }while(MSS < n - n_tx);      
    }
    // getPeriodTime(&times,'b'); //TEST micromedida
    n_tx += write(connfd, buffer + n_tx, n - n_tx);
    // getPeriodTime(&times,'e'); //TEST micromedida
    // throughput = calculateRate(n_tx,times.tvDiff)/1000; //Kbps //TEST micromedida
    // if(config.debug) recordQlevel(i, throughput, qlevel); //TEST micromedida
    // throughput_acum += throughput; //TEST micromedida

    getPeriodTime(&times,'e');
		throughput = calculateRate(n_tx,times.tvDiff)/1000; //Kbps
    // throughput = throughput_acum / counter; //TEST micromedida
		long t_org = throughput;
		throughput = emsrfilter(throughput,throughput_last);
		// throughput = lowpassfilter(throughput,throughput_last);
		throughput_last = throughput;
		if(config.debug){
			printf("enviado: %8d bytes|T: %9li kbps(%9li)|q:%d\n",n_tx,throughput,t_org,qlevel);//TEST
      recordQlevel(i, throughput, qlevel);
    }

		//siguiente fichero a enviar
		qlevel = selectNextSource(throughput,prefix,config,qlevel);
		
	}

}

/*!
 * @brief	selecciona el siguiente fichero en funcion al throughput y el nivel
 * 				de calidad anterior
 * @param [in]	throughput	
 * @param [out]	prefix	prefijo del siguiente fichero a leer y enviar
 * @param [in]	config	configuracion de la aplicaci�n (ver config.ini)
 * @param [in]	qlevel	nivel de calidad anterior
 * @return			nivel de calidad
 */

int selectNextSource(long throughput, char* prefix, config_t config, int qlevel){
	long THP = throughput;
	int qlevel_last = qlevel;
	if( 1100 <= THP ){                     //Quality level : 4
		qlevel = 4;
	}else if(500 <= THP && THP < 1100){   //Quality level : 3
		qlevel = 3;
	}else if(300 <= THP && THP < 500){   //Quality level : 2
		qlevel = 2;
	}else if(THP < 300){                  //Quality level : 1
		qlevel = 1;
	}

	//para eviar los cambios bruscos que nivel de calidad
	if(qlevel > qlevel_last){
		qlevel = qlevel_last + 1;
	}else if(qlevel < qlevel_last){
		qlevel = qlevel_last - 1;
	}
	
	//seleccion del prefijo del fichero H264 que se leera
	switch(qlevel){
		case 1: strcpy(prefix,config.prefixQL1);break;
		case 2: strcpy(prefix,config.prefixQL2);break;
		case 3: strcpy(prefix,config.prefixQL3); break;
		case 4: strcpy(prefix,config.prefixQL4); break;
	}
	
	return qlevel;
}

/**
 *  @brief Convierte un entero a cadena de caracteres.
 *  
 *  @param [in] val entero a convertir.
 *  @return cadena que contiene el valor convertido.
 */
char* itoa(int val){
  int base = 10;
	static char buf[32] = {0};	
	int i = 30;
	
	for(; val && i ; --i, val /= base)
	
		buf[i] = "0123456789abcdef"[val % base];
	
	return &buf[i+1];	
}

/**
 *  @brief Configura el socket TCP
 *  
 *  @param [in] port puerto de escucha.
 *  @return descriptor del socket
 */
int setupSocket(int port){
	struct sockaddr_in serv_addr;
	int listenfd = socket(AF_INET, SOCK_STREAM, 0);
	int serv_addr_size = sizeof(struct sockaddr_in);
  memset(&serv_addr, '0', serv_addr_size);

  serv_addr.sin_family = AF_INET;
  serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
  serv_addr.sin_port = htons(port); 
  bind(listenfd, (struct sockaddr*)&serv_addr, serv_addr_size); 
  listen(listenfd, 10);
	return listenfd;
}


/**
 *  @brief inicializacion de la estructura config_t
 */
static int handler(void* user, const char* section, const char* name, const char* value)
{
    config_t* pconfig = (config_t*)user;

    // #define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
    if (MATCH("files", "inFile")) {
        pconfig->inFile = strdup(value);
    } else if (MATCH("files", "mediadesc")) {
        pconfig->mediadesc = strdup(value);
    } else if (MATCH("server", "port")) {
        pconfig->port = atoi(value);
    } else if (MATCH("tracer", "debug")) {
        pconfig->debug = atoi(value);
    } else if (MATCH("tracer", "debugtcpinfo")) {
        pconfig->debugtcpinfo = atoi(value);
    } else {
        return 0;  /* seccion/nombre desconocidos, error */
    }
    
    
    return 1;
}

/**
 *  @brief Carga de la configuracion contenida en el fichero config.ini
 *  
 *  @param [out] config esctuctura que contendra la configuracion de la app.
 *  @return retorna 0 si la carga se realizo correctamente y 1 si se produjo
 *  algun error durante la carga.
 */
int loadConfiguration(config_t* config){
  if (ini_parse("config.ini", handler, config) < 0) {
    printf("No se pudo cargar la configuration de 'file.ini'\n");
    return 1;
  }
  
  if(config->debug){
    char * cwd; cwd = getcwd (0, 0);
    printf("config params:\n");
    printf("\tConfig file: %s/%s\n",cwd,config->inFile);
    printf("\tpuerto TCP   : %d\n",config->port);
    printf("\tdebug: %d\n\n",config->debug);
  }
  return 0;
}


/**
 *  @brief Crea la el nombre del fichero que contiene un chunk de datos.
 *  El nombre del fichero se forma de la siguiente forma:
 *    filename = prefix + fileNumber + config.extension
 *  
 *  @param [in] config esctuctura que contiene la configuracion de la aplicacion.
 *  @param [in] prefix prefijo del nombre del fichero.
 *  @param [in] fileNumber numero del fichero
 *  @param [out] filename nombre del fichero  
 */
void createFilename(config_t config,char* prefix, int fileNumber, char* filename){
	char* num = itoa(fileNumber);
	strcpy(filename,config.path);
	strcat(filename,prefix);
	strcat(filename,num);
	strcat(filename,config.extension);
}

/**
 *  @brief filtro paso bajo
 *  
 *  @param [in] throughput valor actual
 *  @param [in] throughput_last valor anterior
 *  @return valor filtrado
 */
long lowpassfilter(long throughput, long throughput_last){
	float ALPHA = 0.95;
	return throughput = (ALPHA)*(float)throughput + (1.0-ALPHA)*(float)throughput_last;
}

/**
 *  @brief filtro e.m.s.r. Permite eliminar picos y valles en de una secuencia
 *  de datos.
 *  
 *  @param [in] th valor actual
 *  @param [in] th_last valor anterior
 *  @return valor filtrado
 */
long emsrfilter(long th, long th_last){
	float d = (th_last > 0.0)?((th - th_last)/th_last):0.0;
	float d_limit = 0.7;
	float k_up = 1.5;
	float k_down = 0.5;
	
	if(abs(d) < d_limit){
		return th;
	}else{
		return ( (d > 0.0)?k_up:k_down )*th_last;
	}
}


/**
 *  @brief Carga de los datos de los ficheros que contienen los chunks del 
 *  stream H264/AVC.
 *  
 *  @param [in] config estructura que contiene la configuracion de la app.
 *  @return retorna 0 si la carga de la configuracion fue correcta y 1 si 
 *  ocurrio algun problema durante la carga.
 */
int loadMediaDescription(config_t* config){
	if( access(config->mediadesc, F_OK) != -1){
		if (ini_parse(config->mediadesc, handlerMediaDesc, config) < 0) {
			printf("No se pudo cargar la configuration de '%s'\n",config->mediadesc);
			return 1;
		}
		if(config->debug){
			printf("\tmedia desc : %s\n",config->mediadesc);
			printf("\tpath : %s\n",config->path);
			printf("\tprefixQL1 : %s\n",config->prefixQL1);
			printf("\tprefixQL2 : %s\n",config->prefixQL2);
			printf("\tprefixQL3 : %s\n",config->prefixQL3);
			printf("\tprefixQL4 : %s\n",config->prefixQL4);
			printf("\textension : %s\n",config->extension);
			printf("\tficheros H264: %d\n\n",config->numfiles);
		}
	}else{
		printf("No existe el fichero de configuration: '%s'\n",config->mediadesc);
		return 1;
	}
  return 0;
}

/**
 *  @brief Inicializacion de la esctuctura de configuracion con los datos de los
 *  ficheros que contienen los chunks del stream H264/AVC.
 */
static int handlerMediaDesc(void* user, const char* section, const char* name, const char* value)
{
    config_t* pconfig = (config_t*)user;

    // #define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
    if (MATCH("desc", "path")) {
        pconfig->path = strdup(value);
    } else if (MATCH("desc", "prefixQL4")) {
        pconfig->prefixQL4 = strdup(value);
    } else if (MATCH("desc", "prefixQL3")) {
        pconfig->prefixQL3 = strdup(value);
    } else if (MATCH("desc", "prefixQL2")) {
        pconfig->prefixQL2 = strdup(value);
    } else if (MATCH("desc", "prefixQL1")) {
        pconfig->prefixQL1 = strdup(value);
    } else if (MATCH("desc", "extension")) {
        pconfig->extension = strdup(value);
    } else if (MATCH("desc", "numfiles")) {
        pconfig->numfiles = atoi(value);
    } else {
        return 0;  /* seccion/nombre desconocidos, error */
    }
    
    
    return 1;
}


/**
 *  @brief Guarda en el fichero salida_local.264 la union de los chunks del 
 *  stream H264/AVC
 *  
 *  @param [in] buffer contenido del chunk H264/AVC.
 *  @param [in] size longitud del buffer.
 */
void testSaveLocal(uint8_t* buffer,int size){
	FILE* fd = fopen("salida_local.264","a+");
	fwrite(buffer,1,size,fd);
	fclose(fd);
}

/**
 *  @brief Registra en el fichero stats.txt el estado de la conexion TCP
 *  
 *  @param [in] tcp_work_socket descriptor de la conexion Socket TCP
 */
void recordTCPinfo(int tcp_work_socket){
	FILE* statistics = fopen("stats.txt","a+");
	struct tcp_info tcp_info;
	int errno;
	getPeriodTime(&tstats,'e');
	
	socklen_t tcp_info_length = sizeof(tcp_info);
	if ( getsockopt( tcp_work_socket, SOL_TCP, TCP_INFO, (void *)&tcp_info, &tcp_info_length ) == 0 ) {
		fprintf(statistics,"%.6f %u %u %u %u %u %u %u %u %u %u %u %u\n",
				(tstats.tvDiff.tv_sec + tstats.tvDiff.tv_usec/1e6),
				tcp_info.tcpi_last_data_sent,
				tcp_info.tcpi_last_data_recv,
				tcp_info.tcpi_snd_cwnd,
				tcp_info.tcpi_snd_ssthresh,
				tcp_info.tcpi_rcv_ssthresh,
				tcp_info.tcpi_rtt,
				tcp_info.tcpi_rttvar,
				tcp_info.tcpi_unacked,
				tcp_info.tcpi_sacked,
				tcp_info.tcpi_lost,
				tcp_info.tcpi_retrans,
				tcp_info.tcpi_fackets
				);
		if ( fflush(statistics) != 0 ) {
			fprintf(stderr, "Cannot flush buffers: %s\n", strerror(errno) );
		}
	}
	fclose(statistics);
}

/**
 *  @brief Registra en el fichero "bitrate_qlevel.csv" el bitrate y el nivel de calidad
 *  @param [in] fileNum numero de fichero
 *  @param [in] br bitrate
 *  @param [in] qlevel nivel de calidad
 */
void recordQlevel(int fileNum, long br, int qlevel){
  FILE* brQlevel = fopen("bitrate_qlevel.csv","a+");
  fprintf(brQlevel,"%d,%li,%d\n",fileNum,br,qlevel);
  fclose(brQlevel);
}

