/**
 *  @author Edwin Solorzano <solorzano.em@gmail.com>
 *  @file sender.h
 *  @date	2014-06-28
 *  @version	0.1.5
 */
#include <sys/socket.h>
#include <netinet/tcp.h>

/**Longitud del buffer donde se copia el contenido de un fichero segmento H.264*/
#define MSS 1460
#define READBUFFER_SIZE 5*1024*1024
#define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0

typedef struct
{
    /*@{*/
    const char* inFile;    /**<Nombre del fichero de configuración */
    const char* mediadesc; /**<Nombre del fichero que contiene la descripción de los ficheros segmento H.264*/
    const char* path;      /**<Ruta de la carpeta que contiene los ficheros segmento H.264*/
    const char* prefixQL4; /**<Prefijo de los ficheros segmento de calidad 4*/
    const char* prefixQL3; /**<Prefijo de los ficheros segmento de calidad 3*/
    const char* prefixQL2; /**<Prefijo de los ficheros segmento de calidad 2*/
    const char* prefixQL1; /**<Prefijo de los ficheros segmento de calidad 1*/
    const char* extension; /**<Extensión de los ficheros segmento H.264*/
    int numfiles;          /**<Numero de ficheros segmento H.264*/
    int port;              /**<Puerto de escucha del servidor TCP*/
    int debug;             /**<Bandera de depuración de la aplicación*/
    int debugtcpinfo;      /**<Bandera de depuración de información TCP que proporciona el sistema operativo*/
    /*@}*/
    
    // al agregar un parámetro aqui tambien se debe actualizar la funcion handler()
} config_t;

times_t tstats;

int setupSocket(int port);
char* itoa(int val);
void sendData(int connfd, config_t config);
int selectNextSource(long throughput, char* prefix, config_t config, int qlevel);
static int handler(void* user, const char* section, const char* name, const char* value);
int loadConfiguration(config_t* config);
void createFilename(config_t config,char* prefix, int fileNumber, char* filename);
long lowpassfilter(long throughput, long throughput_last);
long emsrfilter(long throughput, long throughput_last);

int loadMediaDescription(config_t* config);
static int handlerMediaDesc(void* user, const char* section, const char* name, const char* value);

void testSaveLocal(uint8_t* buffer,int size);
void recordTCPinfo(int connfd);
void recordQlevel(int fileNum, long br, int qlevel);