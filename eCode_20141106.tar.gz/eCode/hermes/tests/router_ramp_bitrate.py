import os
cnt = 0
period = 30          #segundos
times = 19*period
selector = 0
print "eth1 bitrate ramp change"
while (cnt < times):
	if((cnt%period)==0):
		selector+=1;
		
	if((selector%6) == 1):
		print "eth1 bitrate  280kbit"
		os.system("tc qdisc replace dev eth1 root tbf rate 280kbit burst 12240 lat 65ms mtu 1540")
	if((selector%6) == 2):
		print "eth1 bitrate  480kbit"
		os.system("tc qdisc replace dev eth1 root tbf rate 480kbit burst 12240 lat 65ms mtu 1540")
	if((selector%6) == 3):
		print "eth1 bitrate 1100kbit"
		os.system("tc qdisc replace dev eth1 root tbf rate 1100kbit burst 12240 lat 65ms mtu 1540")
	if((selector%6) == 4):
		print "eth1 bitrate 2600kbit"
		os.system("tc qdisc replace dev eth1 root tbf rate 2600kbit burst 12240 lat 65ms mtu 1540")
	if((selector%6) == 5):
		print "eth1 bitrate 1100kbit"
		os.system("tc qdisc replace dev eth1 root tbf rate 1100kbit burst 12240 lat 65ms mtu 1540")
	if((selector%6) == 0):
		print "eth1 bitrate  480kbit"
		os.system("tc qdisc replace dev eth1 root tbf rate 480kbit burst 12240 lat 65ms mtu 1540")
		
	os.system("sleep " + str(period))
	cnt+=period
