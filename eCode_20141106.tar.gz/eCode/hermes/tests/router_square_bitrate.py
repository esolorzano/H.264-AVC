import os
cnt = 0
period = 40          #segundos
times = 11*period
selector = 0
print "eth1 bitrate square change"
while (cnt < times):
	if((cnt%period)==0):
		selector+=1;
		
	if((selector%2) == 1):
		print "eth1 bitrate  280kbit"
		os.system("tc qdisc replace dev eth1 root tbf rate 280kbit burst 12240 lat 65ms mtu 1540")
	if((selector%2) == 0):
		print "eth1 bitrate 2600kbit"
		os.system("tc qdisc replace dev eth1 root tbf rate 2600kbit burst 12240 lat 65ms mtu 1540")
		
	os.system("sleep " + str(period))
	cnt+=period
