/**
  @author Edwin Solorzano <solorzano.em@gmail.com>
  @file demux.c
  @date 2013-08-14
  
  Demultiplexor, se encarga de dividir un bitstream h264.\n
  La division se hace en otros bitstream h264. La unidad de division\n
  es el NAL unit.
*/
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include "../h264bitstream-0.1.10/bs.h"
#include "../h264bitstream-0.1.10/h264_stream.h"

/**
  @def NUMERO_CANALES
    numero de canales entre los que se distribuirá el contenido del
    bitstream de entrada.
    
 @def BUFSIZE
    logintud del buffer de lectura del bitstream de entrada
*/
#define NUMERO_CANALES 4
#define BUFSIZE 128*1024*1024 //128MB

#define MSG(msg)  printf("%s\n",msg)
#define testPASS()  printf("%d @ %s()......\n",__LINE__,__FUNCTION__)
#define testSHOWP(p) printf("%d @ %s() - p : %p  ......\n",__LINE__,__FUNCTION__,p)

int debug_mode_on = 1;

int main(int argc, char *argv[]){

  char* infile;
  char* prefix;
  char* outfile[NUMERO_CANALES];  
  
  /*validación de argumentos*/
  if(argc < 2){
    MSG("modo de uso:");
    MSG("\t./demux <h264_stream> [prefijo_salidas]");    
    return 1;
  }else{   
    if(argc >= 2) infile = argv[1];
    if(argc >  2) prefix = argv[2];
    else{
      prefix = (char*)malloc(sizeof(char)*40);
      prefix = strcat(prefix,"canal");
    }
  }
    
  /*apertura y creacion de ficheros*/
  FILE* fsin = fopen(infile,"rb");
  if(!fsin){
    printf("no se pudo abrir el fichero: [%s]\n",infile);
    return 1;
  }  
  
  FILE* fsout[NUMERO_CANALES];  
  for(int i=0;i<NUMERO_CANALES;i++){
    char stmp[10] = {0};
    outfile[i] = (char*)malloc(sizeof(char)*40);
    outfile[i] = strcat(outfile[i],prefix);
    outfile[i] = strcat(outfile[i],"_"); sprintf(stmp,((i<10)?"0%d":"%d"),i);
    outfile[i] = strcat(outfile[i],stmp);
    outfile[i] = strcat(outfile[i],".264");
    // MSG(outfile[i]); //TEST
    fsout[i] = fopen(outfile[i],"wb");
    if(!fsout[i]){
      printf("no se pudo crear el fichero: [%s]\n",outfile[i]);
      return 1;
    }    
  }
  
  /*lectura y division de bitstream entrada*/
  int contador_nal_units = 0;  
  int cnt_0,cnt_1,cnt_2,cnt_3;
  cnt_0=cnt_1=cnt_2=cnt_3=0;

  int nal_start, nal_end;
  uint8_t* buf = (uint8_t*)malloc( BUFSIZE );
  uint8_t* p = buf;  
  size_t rsz = 0;
  size_t sz = 0;
  int64_t off = 0;  
  
  h264_stream_t* h = h264_new();
 
  uint8_t separator[4] = {0,0,0,1};
  
  while (1)
  {
      rsz = fread(buf + sz, 1, BUFSIZE - sz, fsin);
      if (rsz == 0)
      {
          if (ferror(fsin)) { fprintf( stderr, "!! Error: read failed: %s \n", strerror(errno)); break; }
          break;  // if (feof(fsin)) 
      }

      sz += rsz;

      while (find_nal_unit(p, sz, &nal_start, &nal_end) > 0)
      {
          contador_nal_units++;
          p += nal_start;
          read_nal_unit(h, p, nal_end - nal_start);

          
          //distribucion de las NAL units
          switch(h->nal->nal_unit_type){
            case  6:
            case  7:  fwrite(separator,1,4,fsout[0]); fwrite(p,1,nal_end - nal_start,fsout[0]); cnt_0++; break;
            case 15:
            case  8:  fwrite(separator,1,4,fsout[1]); fwrite(p,1,nal_end - nal_start,fsout[1]); cnt_1++; break;
            case 14:
            case  5:  fwrite(separator,1,4,fsout[2]); fwrite(p,1,nal_end - nal_start,fsout[2]); cnt_2++; break;
            case 20:
            case  1:  fwrite(separator,1,4,fsout[3]); fwrite(p,1,nal_end - nal_start,fsout[3]); cnt_3++; break;

            default:  fwrite(separator,1,4,fsout[0]); fwrite(p,1,nal_end - nal_start,fsout[0]); cnt_3++; break;
          }          

          if(debug_mode_on){
            printf("-----------------------------------------\n");
            printf("nal_unit_type : %d |size : %d \n",h->nal->nal_unit_type, nal_end - nal_start);
            if(h->nal->nal_unit_type == NAL_UNIT_TYPE_CODED_SLICE_IDR||
               h->nal->nal_unit_type == NAL_UNIT_TYPE_CODED_SLICE_NON_IDR||
               h->nal->nal_unit_type == NAL_UNIT_TYPE_CODED_SLICE_AUX ||
               h->nal->nal_unit_type == NAL_UNIT_TYPE_CODED_SLICE_EXT){
              
              int slice_type;
              int pic_order_cnt_lsb;
              if(h->nal->nal_unit_type == NAL_UNIT_TYPE_CODED_SLICE_EXT){
                slice_header_svc_t* sh = h->sh_svc;
                slice_type = sh->slice_type;
                pic_order_cnt_lsb = sh->pic_order_cnt_lsb;
              }else{
                slice_header_t* sh = h->sh;
                slice_type = sh->slice_type;
                pic_order_cnt_lsb = sh->pic_order_cnt_lsb;
                // debug_slice_header(h->sh); //TEST
              }
              const char* slice_type_name;
              switch(slice_type)
              {
                case SH_SLICE_TYPE_P :       slice_type_name = "P slice"; break;
                case SH_SLICE_TYPE_B :       slice_type_name = "B slice"; break;
                case SH_SLICE_TYPE_I :       slice_type_name = "I slice"; break;
                case SH_SLICE_TYPE_SP :      slice_type_name = "SP slice"; break;
                case SH_SLICE_TYPE_SI :      slice_type_name = "SI slice"; break;
                case SH_SLICE_TYPE_P_ONLY :  slice_type_name = "P slice only"; break;
                case SH_SLICE_TYPE_B_ONLY :  slice_type_name = "B slice only"; break;
                case SH_SLICE_TYPE_I_ONLY :  slice_type_name = "I slice only"; break;
                case SH_SLICE_TYPE_SP_ONLY : slice_type_name = "SP slice only"; break;
                case SH_SLICE_TYPE_SI_ONLY : slice_type_name = "SI slice only"; break;
                default :                    slice_type_name = "Unknown"; break;
              }              
              printf("slice_type : %d ( %s ) \n",slice_type, slice_type_name);
              printf("pic_order_cnt_lsb : %d \n",pic_order_cnt_lsb);                  
            }
          }
          
          p += (nal_end - nal_start);
          sz -= nal_end;
      }

      // if no NALs found in buffer, discard it
      if (p == buf) 
      {
          fprintf( stderr, "!! Did not find any NALs between offset %lld (0x%04llX), size %lld (0x%04llX), discarding \n",
                 (long long int)off, 
                 (long long int)off, 
                 (long long int)off + sz, 
                 (long long int)off + sz);

          p = buf + sz;
          sz = 0;
      }

      memmove(buf, p, sz);
      off += p - buf;
      p = buf;
  }


  /*separador final*/
  unsigned char btmp[4] = {0,0,0,1};
  for(int i=0;i<NUMERO_CANALES;i++) fwrite(btmp,1,4,fsout[i]);
  
  /*cerrado de ficheros y liberacion de memoria*/
  fclose(fsin);
  for(int i=0;i<NUMERO_CANALES;i++) fclose(fsout[i]);
  
  h264_free(h);
  free(buf);
  
  /*impresión de estadisticas finales*/
  printf("outfile_0: %d\n",cnt_0);
  printf("outfile_1: %d\n",cnt_1);
  printf("outfile_2: %d\n",cnt_2);
  printf("outfile_3: %d\n",cnt_3);
  printf("NAL units totales: %d\n",contador_nal_units);
  
  return 0;
}