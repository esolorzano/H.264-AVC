
#include <stdio.h>
#include <stdlib.h>
#include "../h264bitstream-0.1.10/bs.h"
#include "../h264bitstream-0.1.10/h264_stream.h"

#define MSG(message)  printf("%s\n",message)

typedef struct
{
  char a[10];
  char* b;
}td_t;

void foo(td_t* t){
  char** pb = &t->b;
  printf("%d: b[%p] - pb[%p] | a[%p] \n",__LINE__,t->b,*pb,t->a);
  *pb += 1;  
  printf("%d: b[%p] - pb[%p] | a[%p] \n",__LINE__,t->b,*pb,t->a);
  // t->b = pb;
}
                            
int main(){

  char* a = (char*)malloc(10*sizeof(char));
  free(a);

  td_t t;
  t.b = t.a;
  printf("%d: b[%p] - a[%p] \n",__LINE__,t.b,t.a);
  foo(&t);
  printf("%d: b[%p] - a[%p] \n",__LINE__,t.b,t.a);


  return 0;
}
