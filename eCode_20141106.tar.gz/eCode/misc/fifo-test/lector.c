#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#define BUFSIZE 1024

typedef struct{
  FILE* fd;
}handler_t;

int reader(handler_t* h);

int main(){
  handler_t handler;

  handler.fd = fopen("TEST.264","rb");

  printf("leidos: %d\n",reader(&handler));

  fclose(handler.fd);

  return 0;
}

int reader(handler_t* h){

  FILE* fd = h->fd;
  uint8_t* buffer = (uint8_t*)malloc(BUFSIZE);

  int n = fread(buffer, 1, BUFSIZE, fd);

  return n;
}
