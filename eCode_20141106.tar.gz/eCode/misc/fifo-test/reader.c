#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>

#define MAX_BUF 1024

int main()
{
    int fdw,fdr;
    char * myfifoW = "myfifoW";
    char * myfifoR = "myfifoR";
    char buf[MAX_BUF];
    long numero;

    /* open, read, and display the message from the FIFO */
    fdw = open(myfifoR, O_RDWR | O_NONBLOCK);
    fdr = open(myfifoW, O_RDWR | O_NONBLOCK);
    read(fdr, &numero, sizeof(long));
    read(fdr, buf, MAX_BUF);    
    write(fdw, "Hola writer", sizeof("Hola writer"));
    printf("Received: %s, %li\n", buf,numero);
    close(fdr);
    close(fdw);

    return 0;
}