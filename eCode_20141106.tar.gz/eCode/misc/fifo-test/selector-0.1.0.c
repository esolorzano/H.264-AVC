/**
  @author Edwin Solorzano <solorzano.em@gmail.com>
  @date 2013-10-14
  @file selector.c
  @brief  selecciona un grupo de GOBs segun el criterio que se le\n
  envia por una FIFO y envia un stream con los GOBs que cumplen el criterio.\n\n
  
  El objetivo es enviar grupos de GOPs con los que formar un bloque\n
  de ancho W = a*S1 + b*S2 + ... + mSn.\n\n
  
  Los coheficientes (a,b,...n) se enviar�n por medio de una FIFO, mientras\n
  que el stream se enviar� por otra FIFO.
  
  NOTA: En �sta versi�n no se implementan mecanismos de verificacion de errores.
*/

#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>

int main()
{
    int fdw,fdr;
    char * myfifoS2T = "myfifoS2T"; /*to send messages/data from Selector to Transmitter*/
    char * myfifoT2S = "myfifoT2S"; /*to send messages/data from Transmitter to Selector*/
    
    int X;
    int Y;    
    int xGOBSize, yGOBSize;
    unsigned char source0[512]; //GOP del Source0
    unsigned char source1[2048]; //GOP del Source1
    int totalDataSize;
    
    int i;
    char c;

    /* create the FIFOs (named pipe) */
    mkfifo(myfifoS2T, 0666);
    mkfifo(myfifoT2S, 0666);

    /* open FIFOs */
    fdw = open(myfifoS2T, O_RDWR);
    fdr = open(myfifoT2S, O_RDWR);
    
    memset(source0,11,sizeof(source0));
    memset(source1,22,sizeof(source1));

    xGOBSize = sizeof(source0); /* debe actualizarce en la lectura de GOPs de cada fuente*/
    yGOBSize = sizeof(source1); /* debe actualizarce en la lectura de GOPs de cada fuente*/
    
    while(1){

      /*read OK|START Communication*/
      read(fdr, &c, sizeof(char));
      if(c != 's') continue;

      /* send last max GOBs size*/
      write(fdw,&xGOBSize,sizeof(int));
      write(fdw,&yGOBSize,sizeof(int));
      printf("sent sizes [%d] [%d]\n",xGOBSize,yGOBSize);
    
      /* read "send" command: "x" and "y" coeficients */
      read(fdr, &X, sizeof(int));
      read(fdr, &Y, sizeof(int));      
      printf("GOPs number: X=%d, Y=%d\n",X,Y); //TEST
      
      /* get 'x' GOPs of Source0 */
      //TODO
      /* get 'y' GOPs of Source1 */
      //TODO      
      /* send total data SIZE: 'x' GOPs of Source0 + 'y' GOPs of Source1  */
      totalDataSize = X * sizeof(source0) + Y * sizeof(source1);
      write(fdw,&totalDataSize,sizeof(int));
      /* send 'x' GOPs of Source0 */
      for(i=0;i<X;i++){
        write(fdw,source0,sizeof(source0));
      }
      // printf("we have send %d bytes from Source0\n", X * sizeof(source0)); //TEST
      
      /* send 'y' GOPs of Source1 */
      for(i=0;i<Y;i++){
        write(fdw,source1,sizeof(source1));
      }      
      // printf("we have send %d bytes from Source1\n", Y * sizeof(source1)); //TEST
      
      printf("total send: %d\n", (X * sizeof(source0) + Y * sizeof(source1)));
      // * at the end of each loop, it must to been read x + y GOPs from all Sources
      
    }
    
    close(fdw);
    close(fdr);

    /* remove the FIFO */
    unlink(myfifoS2T);
    unlink(myfifoT2S);

    return 0;
}