/**
  @author Edwin Solorzano <solorzano.em@gmail.com>
  @date 2013-10-14
  @file selector.c
  @version 0.1.2
  @brief  selecciona un grupo de GOBs segun el criterio que se le\n
  envia por una FIFO y envia un stream con los GOBs que cumplen el criterio.\n\n
  
  El objetivo es enviar grupos de GOPs con los que formar un bloque\n
  de ancho W = a*S1 + b*S2 + ... + mSn.\n\n
  
  Los coheficientes (a,b,...n) se enviar�n por medio de una FIFO, mientras\n
  que el stream se enviar� por otra FIFO.
  
  NOTA: En �sta versi�n no se implementan mecanismos de verificacion de errores.
  
  0.1.2
  - Distribution Uniforme de GOBs en una ventana de datos.
  - Simulacion dinamica de GOBs de logitudes variables.
  - Compatible con la version 0.1.1 de t.c
  
  0.1.1
  - Distribution Secuencial de GOBs en una ventana de datos indicado por el Transmitter.
  - Compatible con la versi�n 0.1.1 de t.c
  0.1.0
  - Versi�n inicial, compatible con version 0.1.0 de t.c
*/

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#include <math.h>

#define PESO_MAYOR 0.70

typedef struct{
  int maxGOPs;
  int nGOPs;
  int GOPBaseSize;
}source_t;

typedef struct{
  unsigned char* p;
  long realSize;
  long windowSize;
  source_t source[10];
} status_t;

void distributeGOPs(int source0GOBSize, int source1GOBSize, int WindowData, status_t* sTD);
int genGOPsize(int base);
void initStatus(status_t* status, unsigned char* tempWindow, long windowSize);
int feedWindowData(unsigned char* GOPdata, int GOPsize, status_t* sTW);
int getIndex(status_t* sWD);

int main()
{

    int fdw,fdr;
    char* myfifoS2T = "myfifoS2T"; /*to send messages/data from Selector to Transmitter*/
    char* myfifoT2S = "myfifoT2S"; /*to send messages/data from Transmitter to Selector*/
    
    char c;

    int GOPSize;
    unsigned char* pGOP;
    
    long windowDataSize;
    unsigned char* windowData;
    status_t sWindowData;
    
    srand((unsigned)time(NULL));  
    
    /* create the FIFOs (named pipe) */
    mkfifo(myfifoS2T, 0666);
    mkfifo(myfifoT2S, 0666);

    /* open FIFOs */
    fdw = open(myfifoS2T, O_RDWR);
    fdr = open(myfifoT2S, O_RDWR);
    
    while(1){

      /* read OK|START Communication */
      read(fdr, &c, sizeof(char));
      if(c != 's') continue;
    
      /* read Window Data Size */
      read(fdr, &windowDataSize, sizeof(long));
      // printf("Window Size: %li\n",windowDataSize); //TEST

      /* feed window data */
      //---------------- INI WINDOW FEEDING -----------
      windowData = (unsigned char*)malloc(windowDataSize);
      initStatus(&sWindowData, windowData, windowDataSize);
      sWindowData.source[0].GOPBaseSize = 512;
      sWindowData.source[1].GOPBaseSize = 2048;
      
      /* .: Generar Distribucion*/
      distributeGOPs(sWindowData.source[0].GOPBaseSize,sWindowData.source[1].GOPBaseSize,windowDataSize,&sWindowData);
      
      /* .:seleccionar fuente e insertar GOPs en Window Data*/
      int index = getIndex(&sWindowData);
      sWindowData.source[index].nGOPs++;      
      GOPSize = genGOPsize(sWindowData.source[index].GOPBaseSize);
      pGOP = (unsigned char*)malloc(GOPSize);
      // printf("GOPsize: %d \n",GOPSize); //TEST

      while(feedWindowData(pGOP,GOPSize,&sWindowData)){
        free(pGOP);
        index = getIndex(&sWindowData);
        sWindowData.source[index].nGOPs++;
        GOPSize = genGOPsize(sWindowData.source[index].GOPBaseSize);
        pGOP = (unsigned char*)malloc(GOPSize);
        // printf("GOPsize: %d \n",GOPSize); //TEST
      }
      free(pGOP);
      printf("x: %d, y: %d\n",sWindowData.source[0].nGOPs,sWindowData.source[1].nGOPs);//TEST
      //---------------- END WINDOW FEEDING -----------      
      
      /* send Window Data Size*/
      write(fdw,&sWindowData.realSize,sizeof(long));

      /* send Window Data */
      write(fdw,windowData,sWindowData.realSize);
      free(windowData);
      
      printf("total send: %li\n", sWindowData.realSize);
      // * at the end of each loop, it must to been read x + y GOPs from all Sources
      
    }
    
    close(fdw);
    close(fdr);

    /* remove the FIFO */
    unlink(myfifoS2T);
    unlink(myfifoT2S);

    return 0;
}

/*!
 * Inserta GOPs en una ventana temporal
 * @param[in] GOPdata GOP data buffer
 * @param[in] GOPsize GOP data size
 * @param[in/out] sTW Temporal Window Data Status
 * @return  0 cuando no es posible insertar m�s GOPs, 1 cuando queda espacio disponible para m�s GOPs
 */
int feedWindowData(unsigned char* GOPdata, int GOPsize, status_t* sTW){
  unsigned char* p = sTW->p;
  /* insertar GOP en Temporal Window */
  memcpy(p,GOPdata,GOPsize);
  
  /* actualizar status del Temporal Window*/
  p = p + GOPsize;
  sTW->realSize += GOPsize;
  
  /* Comprobar espacio para m�s GOPs, considerando 100% m�s del GOPsize actual */
  return ((sTW->realSize + 4*GOPsize < sTW->windowSize)?1:0);
}

/*!
 * Calcula el numero de GOPs de cada fuente que el Selector debe enviar.
 * @param[in] source0GOBSize  tama�o de los GOPs del Source0
 * @param[in] source1GOBSize  tama�o de los GOBs del Source1
 * @param[in] WindowData  tama�o total que deber� ocupar todos los GOPs
 * @param[out] sWD  Status de la Ventada de Datos
 */
void distributeGOPs(int source0GOBSize, int source1GOBSize, int WindowData, status_t* sWD){
    int x;
    int y;
    source_t* s = sWD->source;
    
    y = (PESO_MAYOR * WindowData)/source1GOBSize;
    x = ((1 - PESO_MAYOR) * WindowData)/source0GOBSize;
    
    printf("%d %d\n",x,y); //TEST
    
    (s + 0)->maxGOPs = x;
    (s + 1)->maxGOPs = y;
}

/*!
 * Genera numeros con variaciones de +/- 10% del valor base
 * @param[in] base  entero a partir del cual se generar� el nuevo numero.
 * @return  numero +/- 10% del parametro base.
 */

int genGOPsize(int base){
  double PI=3.14159265;
  double delta = 0.10;
  int sign;
  int error;
  int ang;
  // srand((unsigned)time(NULL));  
  ang = rand()%180 + 1;
  sign = (cos(ang*PI/180)<0)?-1:1;
  error = rand() % (int)(delta * base);
  // printf("ang: %d ,sign: %d, error: %d\n",ang,sign,error); //TEST
  return base + sign * error;
}


/*!
 * Inicializa la estructura que registra el estado del la ventana temporal que contiene los GOBs
 * @param[in,out] status  registro del estado de la ventana temporal de datos
 * @param[in] tempWindow  puntero a la ventana temporal de datos
 */
void initStatus(status_t* status, unsigned char* tempWindow, long windowSize){
  int i;
  source_t* s = status->source;
  status->p = tempWindow;
  status->realSize = 0;
  status->windowSize = windowSize;
  for(i=0;i<10;i++){
    (s+i)->maxGOPs = 0;
    (s+i)->nGOPs = 0;
    (s+i)->GOPBaseSize = 0;
  }
}

/*!
 * Obtener el indice de la fuente de GOPs. 
 * Verifica que no se haya alcanzado el m�ximo de GOPs para la distribuci�n.
 * @param[in] sWD estado de la ventana de datos y las fuentes
 */
int getIndex(status_t* sWD){
  source_t* s = sWD->source;
  int index = rand()%2;      
  int exp = (s + index)->nGOPs < (s + index)->maxGOPs;
  
  return ((exp)?index:!index);
} 