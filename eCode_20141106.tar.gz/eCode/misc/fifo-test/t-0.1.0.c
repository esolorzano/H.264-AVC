#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h> 
#include <string.h>

#define MAX_BUF 2*1024*1024
#define PESO_MAYOR 0.70

void getGOBsSize(int* source0GOBSize, int* source1GOBSize);
void getDataFromSelector(unsigned char* buf, unsigned int* TotalData, unsigned int bufSize, int xGOBs, int yGOBs);
void calculateXY(int source0GOBSize, int source1GOBSize, int WindowData, int* X, int* Y);

//================== MAIN =====================================================
int main(int argc, char** argv)
{
  int source0GOBSize;
  int source1GOBSize;
  int WindowData = 1024*1024;
  int TotalData;
  int X,Y;
  unsigned char* buf = (unsigned char*)malloc(MAX_BUF);
  
  getGOBsSize(&source0GOBSize,&source1GOBSize);
  calculateXY(source0GOBSize,source1GOBSize,WindowData,&X,&Y);
  getDataFromSelector(buf,&TotalData,WindowData,X,Y);
  
  
  return 0;
}

/*!
 * Calcula el numero de GOPs de cada fuente que el Selector debe enviar.
 * @param[in] source0GOBSize  tama�o de los GOPs del Source0
 * @param[in] source1GOBSize  tama�o de los GOBs del Source1
 * @param[in] WindowData  tama�o total que deber� ocupar todos los GOPs
 * @param[out] X  numero de GOPs del Source0
 * @param[out] Y  numero de GOPs del Source1
 */
void calculateXY(int source0GOBSize, int source1GOBSize, int WindowData, int* X, int* Y){
    long x;
    long y;
    
    y = (PESO_MAYOR * WindowData)/source1GOBSize;
    x = ((1 - PESO_MAYOR) * WindowData)/source0GOBSize;
    
    // printf("%li %li\n",x,y); //TEST
    
    *X = x;
    *Y = y;
}
 
/*!
 * lee el tama�o maximo de cada GOB segun la fuente a la que pertenece
 * @param[out]  source0GOBSize tama�o de los GOBs del Source0
 * @param[out]  source1GOBSize tama�o de los GOBs del Source1
 */
void getGOBsSize(int* source0GOBSize, int* source1GOBSize){
  int fdw,fdr;
  char * myfifoS2T = "myfifoS2T";
  char * myfifoT2S = "myfifoT2S";
  char c = 's';

  /* open, read, and display the message from the FIFO */
  fdw = open(myfifoT2S, O_RDWR | O_NONBLOCK);
  fdr = open(myfifoS2T, O_RDWR | O_NONBLOCK);

  /* send Start Command */
  write(fdw, &c, sizeof(char));
  
  /* read GOPs size */
  read(fdr, source0GOBSize, sizeof(int));
  read(fdr, source1GOBSize, sizeof(int));
  
  close(fdr);
  close(fdw);    
}

/*!
 * realizar peticion de datos al selector.
 * @param[out] buf   buffer que contiene lo leido del selector. 
 * @param[out] totalDataSize  bytes recibidos del selector.
 * @param[in]  bufSize  capacidad del buffer.
 * @param[in]  xGOBs  numero de GOBs del Source0.
 * @param[in]  yGOBs  numero de GOBs del Source1.
 */
void getDataFromSelector(unsigned char* buf, unsigned int* totalDataSize, unsigned int bufSize, int xGOBs, int yGOBs){

  int fdw,fdr;
  char * myfifoS2T = "myfifoS2T";
  char * myfifoT2S = "myfifoT2S";

  int X = xGOBs;
  int Y = yGOBs;

  int n;
  int counter;
  int TMP_BUF_SIZE = bufSize;
  unsigned char* btmp = (unsigned char*)malloc(TMP_BUF_SIZE);
  
  /* open, write or read data from/to the FIFO */
  fdw = open(myfifoT2S, O_RDWR | O_NONBLOCK);
  fdr = open(myfifoS2T, O_RDWR | O_NONBLOCK);

  /* send 'x' and 'y' coeficients */
  write(fdw, &X, sizeof(int));
  write(fdw, &Y, sizeof(int));

  /* read size of 'x' GOPs of Source0 */
  read(fdr, totalDataSize, sizeof(int));
  if(*totalDataSize > bufSize){printf("....no se leer� todo lo enviado...\n");}
  
  /* read 'x' GOPs of Source0 + 'y' GOPs of Source1 */
  counter = 0;
  do{
    n = read(fdr, btmp, TMP_BUF_SIZE);
    if(n>0){       
      memcpy((buf + counter),btmp,n);
      counter += n;
    }
  }while(counter < *totalDataSize);
  // printf("we have read %d bytes of Source0 & Source1\n", counter); //TEST

  close(fdr);
  close(fdw);  
}
 