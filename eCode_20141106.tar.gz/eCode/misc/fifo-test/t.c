/**
  @author Edwin Solorzano <solorzano.em@gmail.com>
  @date 2013-10-14
  @file t.c
  @version 0.1.2
*/

#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h> 
#include <string.h>
#include <stdint.h>

#define MAX_BUF 16*1024*1024

void getDataFromSelector(uint8_t* buf, long* TotalData, long bufSize);

//================== MAIN =====================================================
int main(int argc, char** argv)
{
  //long WindowData = 2*1020*1024;
  long WindowData = 16*1024;
  long TotalData;
  uint8_t* buf = (uint8_t*)malloc(MAX_BUF);
  
  FILE* fd = fopen("TEST.264","wb");
  
  getDataFromSelector(buf,&TotalData,WindowData);
  
  fwrite(buf,1,TotalData,fd);
  fclose(fd);
  
  return 0;
}

 
/*!
 * realizar peticion de datos al selector.
 * @param[out] buf   buffer que contiene lo leido del selector. 
 * @param[out] totalDataSize  bytes recibidos del selector.
 * @param[in]  windowDataSize  capacidad de la ventana de datos.
 */
void getDataFromSelector(uint8_t* buf, long* totalDataSize, long windowDataSize){

  int fdw,fdr;
  char * myfifoS2T = "../selector/myfifoS2T";
  char * myfifoT2S = "../selector/myfifoT2S";

  int n;
  int counter;
  long TMP_BUF_SIZE = (long)(0.50*windowDataSize); /*50% of Window Data Requested*/
  uint8_t* btmp = (uint8_t*)malloc(TMP_BUF_SIZE);
  
  char c = 's';
  
  /* open, write or read data from/to the FIFO */
  fdw = open(myfifoT2S, O_RDWR | O_NONBLOCK);
  fdr = open(myfifoS2T, O_RDWR);

  /* send Start Command */
  write(fdw, &c, sizeof(char));  
  
  /* send window data size */
  write(fdw, &windowDataSize, sizeof(long));

  /* read window data size to be received */
  read(fdr, totalDataSize, sizeof(long));
  printf("data size: %li\n",*totalDataSize); //TEST
  if(*totalDataSize > windowDataSize){printf("....no se leer� todo lo enviado...\n");}
  
  /* read 'x' GOPs of Source0 + 'y' GOPs of Source1 */
  counter = 0;
  do{
    n = read(fdr, btmp, TMP_BUF_SIZE);
    if(n>0){       
      memcpy((buf + counter),btmp,n);
      counter += n;
    }
  }while(counter < *totalDataSize);
  printf("we have read %d bytes of Source0 & Source1\n", counter); //TEST

  close(fdr);
  close(fdw);  
}
  
