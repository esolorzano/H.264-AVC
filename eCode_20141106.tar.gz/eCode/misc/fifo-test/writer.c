#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define MAX_BUF 1024

int main()
{
    int fdw,fdr;
    char * myfifoW = "myfifoW";
    char * myfifoR = "myfifoR";
    char buf[MAX_BUF];
    long numero = 2*1024*1024;

    /* create the FIFO (named pipe) */
    mkfifo(myfifoW, 0666);
    mkfifo(myfifoR, 0666);

    /* write "Hi" to the FIFO */
    fdw = open(myfifoW, O_RDWR);
    fdr = open(myfifoR, O_RDWR);
    write(fdw,&numero,sizeof(long));
    write(fdw, "Hi Reader", sizeof("Hi Reader"));    
    read(fdr, buf, MAX_BUF);
    printf("Received: %s\n", buf);
    close(fdw);
    close(fdr);

    /* remove the FIFO */
    unlink(myfifoR);
    unlink(myfifoW);

    return 0;
}