//logger.h
#define LOG_PRINT(...) log_print(__FILE__, __LINE__, __VA_ARGS__ )
