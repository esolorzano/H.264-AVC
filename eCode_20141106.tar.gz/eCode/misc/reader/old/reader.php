<?php
  // echo dechex(0)."\n";
  // die("\n");
  $fichero = 'foreman_tx.264';
  if(!($fd=fopen($fichero,'rb'))) echo "no se pudo abrir el fichero";
  else{
    $cnt = 0;
    $buffer = array();
    $index = 0;
    while(!feof($fd)){
      $number = unpack("c",fread($fd,1));
      $number = 0xFF&$number[1];
      $string = (($number<0x10)?"0":"").strtoupper(dechex($number));
      $buffer[$index++] = $string;
      if($index > 4){
        //reconocimiento cabecera
        $str2check = $buffer[($index-4)].$buffer[($index-3)].$buffer[($index-2)].$buffer[($index-1)];
        if(strcmp($str2check,"00000001")===0){
          //mostrar contenido NAL
          $cnt = 0;
          foreach($buffer as $data){
            echo $data." ";
            echo (((++$cnt%16)==0)?"\n":"");
          }
          //reiniciar buffer y contador
          $buffer = array();
          $index = 0;
          echo "\n============================\n";
        }
      }
      // echo $string." ";
      // echo (((++$cnt%16)==0)?"\n":"");
    }
    fclose($fd);
  }
?>
