

typedef struct {
  struct{ unsigned char value; unsigned char nbits;} profile_idc, constraint_set0_flag;
} SPSstructure;