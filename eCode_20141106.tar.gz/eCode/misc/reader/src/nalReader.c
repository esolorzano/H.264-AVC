/**

@author: Edwin Solorzano
@email: solorzano.em@gmail.com
@date : 10/07/2013
@file   nalReader.c
@brief  Lector de NAL units (solo identificación de NAL units y tipos)

Información: NAL units format http://www.ietf.org/rfc/rfc3984.txt

Objetivos:


1.- Adaptarse automáticamente al tipo de separador de NAL units (0x000001 o 0x00000001). Para ésto toma en cuenta el identificador del NAL unit (en la norma vigente va del 0 al 31).\n

2.- Mediante argumentos de ejecución mostrar los siguientes datos:\n
  -t : muestra en una lista el numero NAL units por tipo\n
  -n : indica el número de NAL units presentes en el stream\n
  
3.- Crear un set de funciones que se puedan emplear en otros desarrollos.\n

 PASOS\n
      Identificación de separador de NAL units: \n
      1.- leer el stream H264, \n
      2.- usar el separador 0x000001, \n
      3.- validar el tipo de NAL unit, \n
      4.- si el tipo no corresponde a un tipo valido cambiar de patron de separador a 0x00000001 y repetir paso "1"\n
      5.- si el tipo no corresponde a un tipo valido y ya se cambió de patron de separador mostrar un mensaje y finalizar la ejecución.\n
      
      Obtner Información del Stream\n
      1.- Llevar al cuenta del numero de NAL units por tipo\n
      2.- Llevar la cuenta total de NAL units\n

      Mostrar Información del Stream\n
      -t : listar estadisticas de los tipos de NAL units presentes en el stream \n
      -n : indicar el numero total de NAL units presentes en el stream \n
      -d : mostrar las NAL units (datos) \n
      -s : mostrar la secuencia de NAL units (tipo) \n
 */

#include <stdio.h>
#include "../../lib/logger.h"
#include "reader.h"

#define BUFSIZE 100*1024*1024 //100MB

//===== MAIN =====//
int main(int argc, char *argv[]){



    FILE *fstream;
    char *sStreamH264;
    
    int mostrarNALStats=0,mostrarNALcount=0,mostrarNALData=0, mostrarNALSequence=0;
    int nOpciones = 0;
    
    /*! @var b
      debe ser de tipo int para identificar el EOF */
    int b; 
    unsigned char aBufferData[BUFSIZE] = {0};
    unsigned char aBufferHeader[100] = {0};
    nalHeadData aStatsNALType[BUFSIZE] = {0};
    int iNALCounter=0;
    int tipoSeparador = -1;        
    
    int i;
    int index=0;
    unsigned char *p;
       
    //====== validación de entradas
    if ( argc < 3 ){        
        printf("argumentos incompletos!\n");
        printf( "uso: %s <-t|-n|-d|-s> <nombre_fichero_h264>\n", argv[0] );
        printf("-t : muestra numero de NAL units por tipo\n");
        printf("-n : muestra el numero de NAL units presentes en el stream\n");
        printf("-d : muestra los datos de las NAL units, sin parsear\n");
        printf("-s : muestra la secuencia de NAL units (tipo)\n");
        // LOG_PRINT( "uso: %s <nombre_fichero_h264>", argv[0] );
        
        return 1;
    }else{
      for(i=1;i<argc;i++){
        if(strcmp(argv[i],"-t")==0){
          mostrarNALStats = 1;
          nOpciones++;
        }else if(strcmp(argv[i],"-n")==0){
          mostrarNALcount = 1;
          nOpciones++;
        }else if(strcmp(argv[i],"-d")==0){
          mostrarNALData = 1;
          nOpciones++;
        }else if(strcmp(argv[i],"-s")==0){
          mostrarNALSequence = 1;
          nOpciones++;
        }else if(nOpciones==(argc-2)){
          sStreamH264 = argv[i]; //nombre del stream
        }
      }
      
      printf("procesando: [%s]\n",sStreamH264);
      printf("se mostrara: estadisticas[%d] : totales [%d] : datos [%d] : secuencia[%d]\n",mostrarNALStats,mostrarNALcount,mostrarNALData,mostrarNALSequence);
      printf("-----------------------------------------------------------------\n\n");
      // LOG_PRINT("procesando: [%s]",sStreamH264);
    }

    //====== apertura y verificación del fichero    
    fstream = fopen(sStreamH264,"rb");
    if(!fstream){
      printf("no se pudo abrir el fichero: [%s]\n",sStreamH264);
      return 1;
    }

    //====== identifica separador
    tipoSeparador = identificaSeparadorNAL(fstream);
    // printf("(%d)\n",tipoSeparador); //TEST
    
    //====== Obtener información de las NAL units
    while((b = fgetc(fstream))!= EOF){        
      aBufferData[index++]=b;        
      if(findNAL(tipoSeparador,aBufferHeader,b)){
        p = aBufferData + ((iNALCounter==0)?(3+tipoSeparador):0);
        analizaCabeceraNAL(p,aStatsNALType,iNALCounter);
        if(mostrarNALData) imprimeNAL(p,index,aStatsNALType,iNALCounter);
        iNALCounter++;      
      
        // dumpBuffer(aBufferData,index); //TEST
        if(index>5) index=0; //para no perder la primera NAL unit
      }
    }

    //====== Impresion de datos solicitados
    printf("\n-----------------------------------------------------------------\n");
    if(mostrarNALStats) imprimirStats(aStatsNALType,iNALCounter);
    if(mostrarNALcount) printf("el stream [%s] contiene (%d) NAL units\n\n",sStreamH264,iNALCounter);
    if(mostrarNALSequence) imprimirNALSequence(aStatsNALType,iNALCounter);
    
    
    fclose(fstream);
    return 0;
}
