/**

@author   Edwin Solorzano
@email    solorzano.em@gmail.com
@date     10/07/2013
@file     reader.c
@brief    libreria para lectura de NAL units H.264

Información: NAL units format http://www.ietf.org/rfc/rfc3984.txt

*/

#include <stdio.h>
#include "../../lib/logger.h"
#include "reader.h"

/*! 
Identifica una NAL unit. El tipo de separador está indicado por "mode"
@param[in]      mode          Tipo de separador (MODE_0 para 0x000001 y MODE_1 para 0x00000001)
@param[in,out]  pBufferHeader Buffer donde se guardan los ultimos bytes leidos para buscar el separador
@param[in]      iByte         Byte leido del stream
*/
int findNAL(int mode, unsigned char *pBufferHeader,unsigned char iByte){
  
  int i;
  int eval = 1;
  unsigned char aTemp[5] = {0};
  unsigned char *p = pBufferHeader;
     
  if(mode == MODE_0){
    //pBufferHeader + iByte ---> aTemp
    for(i=0;i<3;i++) *(aTemp + i) = *(pBufferHeader + i + 1);  
    *(aTemp + i) = iByte;
    
    // aTemp --> pBufferHeader
    for(i=0;i<4;i++) *(pBufferHeader + i) = *(aTemp + i);
    
    // evaluacion: pBufferHeader[] = 0x000001
    eval = eval && (*(p+0)!=00);
    eval = eval && (*(p+1)==00);
    eval = eval && (*(p+2)==00);
    eval = eval && (*(p+3)==01);
    
  }else if(mode == MODE_1){
    //pBufferHeader + iByte ---> aTemp
    for(i=0;i<4;i++) *(aTemp + i) = *(pBufferHeader + i + 1);  
    *(aTemp + i) = iByte;
    
    // aTemp --> pBufferHeader
    for(i=0;i<5;i++) *(pBufferHeader + i) = *(aTemp + i);
    
    // evaluacion: pBufferHeader[] = 0x00000001
    eval = eval && (*(p+0)!=00);
    eval = eval && (*(p+1)==00);
    eval = eval && (*(p+2)==00);
    eval = eval && (*(p+3)==00);
    eval = eval && (*(p+4)==01);
  }
  
  return (eval==1)?1:0;
}

/*! 
Imprime en pantalla una NAL unit.
@param[in]      pBufferData   Buffer que contiene los datos de la NAL unit
@param[in]      iDatos        Numero de elementos de pBufferData
@param[in]      aStatsNALType Arreglo que contiene los datos de cabecera de cada NAL unit
@param[in]      index         Indice del actual NAL unit, se usar para acceder la informacion de la cabecera en aStatsNALType
*/
void imprimeNAL(unsigned char *pBufferData, int iDatos, nalHeadData *aStatsNALType, int index){  
  // printf("size: %d\n",iDatos); //TEST
  int i;

  printf("forbidden_zero_bit:(%X)\n",(*(aStatsNALType + index)).f);
  printf("nal_ref_idc:(%X)\n",(*(aStatsNALType + index)).nri);
  printf("nal_unit_type:(%X)\n",(*(aStatsNALType + index)).type);    
  
  for(i=0;i<(iDatos-4);i++){
    if(*(pBufferData + i)<0x10) printf("0");
    printf("%X ",*(pBufferData + i));
    if(((i+1)%16)==0) printf("\n");
  }
  
  printf("\n====================================\n");
}

/*! 
Identifica cada uno de los datos de la cabecera de una NAL unit
@param[in]      pBufferData   Buffer que contiene los datos de la NAL unit
@param[out]     aStatsNALType Arreglo que contiene los datos de cabecera de cada NAL unit
@param[in]      index         Indice del actual NAL unit, se usar para acceder la informacion de la cabecera en aStatsNALType
*/
void analizaCabeceraNAL(unsigned char *pBufferData, nalHeadData *aStatsNALType, int index){  

  (*(aStatsNALType + index)).f    = (*(pBufferData)&0x80) >>7;
  (*(aStatsNALType + index)).nri  = (*(pBufferData)&0x60) >>5;
  (*(aStatsNALType + index)).type = (*(pBufferData)&0x1F);
  
  /*
  Para identificar el tipo de NAL unit consultar la siguiente tabla
  Table 7-1 – NAL unit type codes, syntax element categories, and NAL unit type classes
  */  
}

/*!
Obtiene el tipo de una NAL unit
@param[in]      pBufferData   Buffer que contiene los datos de la NAL unit
@return         entero 0 a 31
*/
unsigned int getNALunitType(unsigned char *pBufferData){
  return (*(pBufferData)&0x1F);
}

/*!
Identifica el tipo de separador usado en un stream para las NAL units
@param[in]      fstream       nombre del stream/fichero en formato H.264
@return         0 para 0x000001 y 1 para 0x00000001
*/
int identificaSeparadorNAL(FILE *fstream){
    int b;
    unsigned char aBufferHeader[100] = {0};
    int iNALCounter_Mode_0 = 0;
    int iNALCounter_Mode_1 = 0;
    
    //====== identificar separador 0x000001
    while((b = fgetc(fstream))!= EOF){ 
      if(findNAL(MODE_0,aBufferHeader,b)){
        iNALCounter_Mode_0++;
      }
    }
    rewind(fstream);    

    //====== identificar separador 0x00000001    
    while((b = fgetc(fstream))!= EOF){
      if(findNAL(MODE_1,aBufferHeader,b)){
        iNALCounter_Mode_1++;
      }
    }
    rewind(fstream);
    
    //====== configurando identificador separador de NAL units
    if(iNALCounter_Mode_0 > iNALCounter_Mode_1) return MODE_0;
    else return MODE_1;
}

/*!
Imprime en pantalla el numero de NAL units por tipo
@param[in]  aStatsNALType Arreglo que contiene los datos de cabecera de cada NAL unit
@param[in]  nNALUnits     Numero de NAL unit contenidas en aStatsNALType
*/
void imprimirStats(nalHeadData *aStatsNALType, int nNALUnits){
  int i;
  int stats[100]={0};
  for(i=0;i<nNALUnits;i++){
    stats[(*(aStatsNALType+i)).type]++;
  }
  
  for(i=0;i<100;i++){
    if(stats[i]) printf("tipo(%2d) : %3d \n",i,stats[i]);
  }
  
  printf("\n");
}

/*!
Imprime en pantalla la secuencia de NAL units (usando el identificador del tipo de NAL unit)
@param[in]  aStatsNALType Arreglo que contiene los datos de cabecera de cada NAL unit
@param[in]  nNALUnits     Numero de NAL unit contenidas en aStatsNALType
*/
void imprimirNALSequence(nalHeadData *aStatsNALType, int nNALUnits){
  int i;
  printf("Secuencia de NAL Units: ");
  for(i=0;i<nNALUnits;i++){
    printf("%d ",(*(aStatsNALType + i)).type);
  }
  printf("\n");
}

/*!
Imprime el contenido del buffer temporal donde se van guardando los bytes que se leen del Stream H264
@param[in]      pBufferData   Buffer que contiene los datos de la NAL unit
@param[in]      index         Numero de bytes de la NAL unit contenidas en pBufferData
*/
void dumpBuffer(unsigned char *aBufferData,int index){
  int i;
  for(i=0;i<index;i++){
    if(aBufferData[i]<16) printf("0");
    printf("%X ",aBufferData[i]);
  }
  printf("\n--------------------\n");
}


void showinfoSEI(unsigned char *pBufferData){
  int payloadType__nalOffset = 1;
  int payloadSize__nalOffset = 2;
  int payloadType = *(pBufferData + payloadType__nalOffset);
  int payloadSize = *(pBufferData + payloadSize__nalOffset);
  
  printf("\t [SEI] payloadType: %d\n",payloadType);
  printf("\t [SEI] payloadSize: %d\n",payloadSize);
}

void showinfoSPS(unsigned char *pBufferData){
  int profile_idc__nalOffset = 1;
  int constraint_set__nalOffset = 2;
  int level_idc__nalOffset = 3;
}