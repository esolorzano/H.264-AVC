/**

@author: Edwin Solorzano
@email: solorzano.em@gmail.com
@date : 10/07/2013
@file   reader.h

Información: NAL units format http://www.ietf.org/rfc/rfc3984.txt

*/
 /**
 @def MODE_0 
    para el separador 0x000001
 
 @def MODE_1 
    para el separador 0x00000001
 */
#define MODE_0 0
#define MODE_1 1

/** 
@struct nalHeadData
  Cabecera de NAL unit (http://www.ietf.org/rfc/rfc3984.txt)
*/
typedef struct{
  /*! forbidden_zero_bit*/
  unsigned int f;
  /*! nal_ref_idc*/
  unsigned int nri;
  /*! nal_unit_type*/
  unsigned int type;
} nalHeadData;


//===== prototipos =====//

int findNAL(int mode, unsigned char *pBufferHeader, unsigned char iByte);
void imprimeNAL(unsigned char *pBufferData, int iDatos, nalHeadData *aStatsNALType, int index);
void analizaCabeceraNAL(unsigned char *pBufferData,nalHeadData *aStatsNALType, int index);
unsigned int getNALunitType(unsigned char *pBufferData);
int identificaSeparadorNAL(FILE *fstream);
void imprimirStats(nalHeadData *aStatsNALType, int nNALUnits);
void imprimirNALSequence(nalHeadData *aStatsNALType, int nNALUnits);

void dumpBuffer(unsigned char *aBufferData,int index);

void showinfoSEI(unsigned char *pBufferData);
void showinfoSPS(unsigned char *pBufferData);