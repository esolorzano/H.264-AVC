/*
Información: NAL units format
http://www.ietf.org/rfc/rfc3984.txt

*/

#include <stdio.h>
#include "h264.h"

//===== prototipos =====//

int findNAL(unsigned char *pBufferHeader, unsigned char iByte);
void imprimeNAL(unsigned char *pBufferData, int iDatos);
void analizaNAL(unsigned char *pBufferData, int iDatos, unsigned int *pAStats);
void showinfoSEI(unsigned char *pBufferData);
void showinfoSPS(unsigned char *pBufferData);

//===== MAIN =====//
int main(int argc, char *argv[]){
    FILE *fstream;
    // char *stream264 = "../foreman_tx.264";
    char *stream264;
    int b=-1;
    int index=0;
    unsigned char aBufferHeader[4] = {0};
    unsigned char aBufferData[10000] = {0};
    int iNALCounter = 0;
    unsigned int aStatsNALType[32] = {0};
    int i;

    
    //validación de entradas
    if ( argc != 2 ){
        /* We print argv[0] assuming it is the program name */
        printf( "uso: %s stream264", argv[0] );
        return 1;
    }else{
      stream264 = argv[1];
    }
    
    //apertura y verificación del fichero
    fstream = fopen(stream264,"rb");
    if(!fstream){
      printf("no se pudo abrir el fichero: %s\n",stream264);
      return 1;
    }
    
    //identificación y análisis de NALs
    while((b = fgetc(fstream))!= EOF){ 

      aBufferData[index++]=b;
        
      if(findNAL(aBufferHeader,b)){       
        if(index>5){
          analizaNAL(aBufferData,index,aStatsNALType);
          imprimeNAL(aBufferData,index);          
          iNALCounter++;
        }
        index = 0;
        printf("\n====================================\n");          
      }
    
    }

    fclose(fstream);
    
    //impresion de estadisticas
    printf("estadísticas por tipo de NAL unit:\n");
    for(i=0;i<32;i++){
      if(aStatsNALType[i] > 0)
        printf("numero de NAL units tipo %2d: %4d\n",i,aStatsNALType[i]);
    }
    printf("total de NAL units: %d\n",iNALCounter);
    
    return 0;
}


//===== funciones =====//

int findNAL(unsigned char *pBufferHeader,unsigned char iByte){
  
  int i;
  int eval = 1;
  unsigned char aTemp[4] = {0};
  unsigned char *p = pBufferHeader;
  
  //pBufferHeader + iByte ---> aTemp
  for(i=0;i<3;i++) *(aTemp + i) = *(pBufferHeader + i + 1);  
  *(aTemp + i) = iByte;
  
  // aTemp --> pBufferHeader
  for(i=0;i<4;i++) *(pBufferHeader + i) = *(aTemp + i);
  
  // evaluacion: pBufferHeader[] = 0x00000001
  eval = eval && (*(p+0)==00);
  eval = eval && (*(p+1)==00);
  eval = eval && (*(p+2)==00);
  eval = eval && (*(p+3)==01);
  
  return (eval==1)?1:0;
}

void imprimeNAL(unsigned char *pBufferData, int iDatos){  
  // printf("size: %d\n",iDatos); //TEST
  int i;
  
  for(i=0;i<(iDatos-4);i++){
    if(*(pBufferData + i)<0x10) printf("0");
    printf("%X ",*(pBufferData + i));
    if(((i+1)%16)==0) printf("\n");
  }
}

void analizaNAL(unsigned char *pBufferData, int iDatos, unsigned int *pAStats){  
  unsigned int f,nri,type;
  f    = (*(pBufferData)&0x80) >>7;
  nri  = (*(pBufferData)&0x60) >>5;
  type = (*(pBufferData)&0x1F);
  
  *(pAStats + type)+=1;
  
  printf("forbidden_zero_bit:(%X)\n",f);
  printf("nal_ref_idc:(%X)\n",nri);
  printf("nal_unit_type:(%X)\n",type);
  
  if(type==6) showinfoSEI(pBufferData);
  if(type==6) showinfoSPS(pBufferData);
  
  /*
  Para identificar el tipo de NAL unit consultar la siguiente tabla
  Table 7-1 – NAL unit type codes, syntax element categories, and NAL unit type classes
  */
  
}

void showinfoSEI(unsigned char *pBufferData){
  int payloadType__nalOffset = 1;
  int payloadSize__nalOffset = 2;
  int payloadType = *(pBufferData + payloadType__nalOffset);
  int payloadSize = *(pBufferData + payloadSize__nalOffset);
  
  printf("\t [SEI] payloadType: %d\n",payloadType);
  printf("\t [SEI] payloadSize: %d\n",payloadSize);
}

void showinfoSPS(unsigned char *pBufferData){
  int profile_idc__nalOffset = 1;
  int constraint_set__nalOffset = 2;
  int level_idc__nalOffset = 3;
}
