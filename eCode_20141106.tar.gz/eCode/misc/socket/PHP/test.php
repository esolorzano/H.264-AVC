<?php
error_reporting(E_ALL);


$options = array("SO_DEBUG"=>SO_DEBUG,
                 "SO_BROADCAST"=>SO_BROADCAST,
                 "SO_REUSEADDR"=>SO_REUSEADDR,
                 "SO_KEEPALIVE"=>SO_KEEPALIVE,
                 "SO_LINGER"=>SO_LINGER,
                 "SO_OOBINLINE"=>SO_OOBINLINE,
                 "SO_SNDBUF"=>SO_SNDBUF,
                 "SO_RCVBUF"=>SO_RCVBUF,
                 "SO_ERROR"=>SO_ERROR,
                 "SO_TYPE"=>SO_TYPE,
                 "SO_DONTROUTE"=>SO_DONTROUTE,
                 "SO_RCVLOWAT"=>SO_RCVLOWAT,
                 "SO_RCVTIMEO"=>SO_RCVTIMEO,
                 "SO_SNDTIMEO"=>SO_SNDTIMEO,
                 "SO_SNDLOWAT"=>SO_SNDLOWAT,
                 "TCP_NODELAY"=>TCP_NODELAY,
                 // "MCAST_JOIN_GROUP"=>MCAST_JOIN_GROUP,
                 // "MCAST_LEAVE_GROUP"=>MCAST_LEAVE_GROUP,
                 // "MCAST_BLOCK_SOURCE"=>MCAST_BLOCK_SOURCE,
                 // "MCAST_UNBLOCK_SOURCE"=>MCAST_UNBLOCK_SOURCE,
                 // "MCAST_JOIN_SOURCE_GROUP"=>MCAST_JOIN_SOURCE_GROUP,
                 // "MCAST_LEAVE_SOURCE_GROUP"=>MCAST_LEAVE_SOURCE_GROUP,
                 "IP_MULTICAST_IF"=>IP_MULTICAST_IF,
                 "IPV6_MULTICAST_IF"=>IPV6_MULTICAST_IF,
                 "IP_MULTICAST_LOOP"=>IP_MULTICAST_LOOP,
                 "IPV6_MULTICAST_LOOP"=>IPV6_MULTICAST_LOOP,
                 "IP_MULTICAST_TTL"=>IP_MULTICAST_TTL,
                 "IPV6_MULTICAST_HOPS"=>IPV6_MULTICAST_HOPS
                 );

echo "<h2>TCP/IP Connection</h2>\n";

/* Get the port for the WWW service. */
$service_port = getservbyname('www', 'tcp');

/* Get the IP address for the target host. */
$host = 'www.hexagon.com';
$address = gethostbyname($host);

/* Create a TCP/IP socket. */
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if ($socket === false) {
    echo "socket_create() failed: reason: " . socket_strerror(socket_last_error()) . "\n";
} else {
    echo "OK.\n";
}

echo "Attempting to connect to '$address' on port '$service_port'...";
$result = socket_connect($socket, $address, $service_port);
if ($result === false) {
    echo "socket_connect() failed.\nReason: ($result) " . socket_strerror(socket_last_error($socket)) . "\n";
} else {
    echo "OK.\n";
}

// foreach($options as $k=>$v){
  // $type = socket_get_option($socket, SOL_SOCKET, $v);
  // if(is_array($type)) print_r($type);
  // else echo "$k: $v\n";
// }

$in = "HEAD / HTTP/1.1\r\n";
$in .= "Mozilla/5.0 (iPad; U; CPU OS 3_2_1 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Mobile/7B405\r\n";
$in .= "Host: $host\r\n";
$in .= "Connection: Close\r\n\r\n";
$out = '';

echo "Sending HTTP HEAD request...";
socket_write($socket, $in, strlen($in));
echo "OK.\n";

echo "Reading response:\n\n";
while ($out = socket_read($socket, 2048)) {
    echo $out;
}

echo "Closing socket...";
socket_close($socket);
echo "OK.\n\n";
?>