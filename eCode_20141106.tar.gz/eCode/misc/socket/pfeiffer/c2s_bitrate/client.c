#include "common.h"




int main(int argc, char **argv){

  int sock;
  struct sockaddr_in server_addr;
  int port = DEFAULT_PORT;
  char* servIP = DEFAULT_SERVER;
  char buffer[BUFSIZE];
  // char *buffer;
  int n;
  
  struct timeval tvBegin, tvEnd, tvDiff;
  float bitrate;
  int size = BUFSIZE;
  int i;
  
  if(argc == 3){
    servIP = argv[2];
  }
  
  /* Crear socket */
  if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
    printf("socket() failed");
  
  /* Asociar puerto a socket */
  memset(&server_addr, 0, sizeof(server_addr));     /* Zero out structure */
  server_addr.sin_family= AF_INET;             /* Internet address family */
  // server_addr.sin_addr.s_addr = inet_addr(servIP);   /* Server IP address */
  setaddrbyname(&server_addr,servIP);
  server_addr.sin_port= htons(port); /* Server port */

  if (connect(sock, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0)
    printf("connect() failed");    

  /* Enviar datos al servidor */
  // for(size = 1024; size < 1024*16; size += 1024){ 
  for(i=0; i < 32; i++){ 
    // buffer = (char *) malloc(size*sizeof(char));
    memset(buffer,'1',size);
    gettimeofday(&tvBegin, NULL);
    n = write(sock,buffer,size);
    gettimeofday(&tvEnd, NULL);
    timeval_subtract(&tvDiff, &tvEnd, &tvBegin);
    bitrate = calculateRate(n,tvDiff)/1000/1000;
    printf("%dbytes in %ld.%06ld - rate=%.2fMbps\n", n, tvDiff.tv_sec, tvDiff.tv_usec, bitrate);
      
    if (n < 0) 
    {
         perror("ERROR writing to socket");
         exit(1);
    }
  }

  
  /* Finalizar conexion */
  close(sock);
}