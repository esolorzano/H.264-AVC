#include "common.h"

int setaddrbyname(struct sockaddr_in *addr, char *host){
  struct addrinfo hints, *res;
  int status;
  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_INET;
  hints.ai_socktype = SOCK_DGRAM;
  if ((status = getaddrinfo(host, NULL, &hints, &res)) != 0) {
    fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(status));
    return -1;
  }
  addr->sin_addr.s_addr = ((struct sockaddr_in *)res->ai_addr)->sin_addr.s_addr;
  freeaddrinfo(res);
  return 0;
}

/**
 *  @brief Calcula el tiempo transcurrido en un periodo
 *  
 *  @param [out] result diferencia de tiempo
 *  @param [in] t2 instante final
 *  @param [in] t1 instante inicial
 *  @return 0: diferencia positiva, 1: diferencia negativa
 */
int timeval_subtract(struct timeval *result, struct timeval *t2, struct timeval *t1)
{
    long int diff = (t2->tv_usec + 1000000 * t2->tv_sec) - (t1->tv_usec + 1000000 * t1->tv_sec);
    result->tv_sec = diff / 1000000;
    result->tv_usec = diff % 1000000;

    return (diff<0);
}

/**
 *  @brief Calcula el bitrate en bits-per-second (bps)
 *  
 *  @param [in] diff ventana de tiempo empleado para enviar datos
 *  @param [in] sizeData tama�o de los datos enviados
 *  @return bitrate en bps
 */
float calculateRate(int sizeData, struct timeval diff){
  return 8*sizeData/((float)diff.tv_sec + (float)diff.tv_usec/1000000);
}