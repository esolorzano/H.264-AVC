#include "common.h"

#define MAXPENDING 5    /* Maximum outstanding connection requests */

int main(char arg, char **argv){

  int sockServer;
  int sockClient;
  struct sockaddr_in server_addr; /* Local address */
  struct sockaddr_in client_addr; /* Client address */
  int client_addr_len;
  int port = DEFAULT_PORT;
  char buffer[BUFSIZE];
  int n;
  
  struct timeval tvBegin, tvEnd, tvDiff;
  float bitrate;
  time_t curtime;
  struct tm *info;

  /* Crear el socket */
   if ((sockServer = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0){
    printf("socket() failed\n");
  }
  /* Asociar el puerto al socket */
  memset(&server_addr, 0, sizeof(server_addr));   /* Zero out structure */
  server_addr.sin_family = AF_INET;                /* Internet address family */
  server_addr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
  server_addr.sin_port = htons(port);      /* Local port */
  
  if (bind(sockServer, (struct sockaddr *) &server_addr, sizeof(server_addr)) < 0)
    printf("bind() failed");
  
  /* Escuchar */
  if (listen(sockServer, MAXPENDING) < 0)
    printf("listen() failed");

  /* Recibir datos de manera continua */
  /* Set the size of the in-out parameter */
  client_addr_len = sizeof(client_addr);
  while(1){
    /* Wait for a client to connect */
    if ((sockClient = accept(sockServer, (struct sockaddr *) &client_addr, &client_addr_len)) < 0)
      printf("accept() failed");
    /* sockClient is connected to a client! */
    // printf("Handling client %s\n", inet_ntoa(client_addr.sin_addr));
    do{
      gettimeofday(&tvBegin, NULL);
      n = read( sockClient,buffer,BUFSIZE );
      
      gettimeofday(&tvEnd, NULL);
      timeval_subtract(&tvDiff, &tvEnd, &tvBegin);
      bitrate = calculateRate(n,tvDiff)/1000/1000;
      bzero(buffer,BUFSIZE);
      
      curtime = time( NULL );
      info = localtime( &curtime );
      strftime(buffer, 30, "%Y-%m-%d  %T", info);
      printf("[%s] - ", buffer);
      printf("%dbytes in %ld.%06ld -> rate=%6.2fMbps\n", n, tvDiff.tv_sec, tvDiff.tv_usec, bitrate);
      
      if (n < 0)
      {
          perror("ERROR reading from socket");
          exit(1);
      }
    }while(n!=0);
    // printf("Here is the message: %s\n",buffer);
    bzero(buffer,BUFSIZE);
  }
  
  /* [Registrar las estadisticas de los datos recibidos]*/
  
  /* Finalizar */
  close(sockServer);
}