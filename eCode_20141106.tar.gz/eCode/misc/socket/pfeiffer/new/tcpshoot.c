#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <time.h>
#include <fcntl.h>
#include <errno.h>
#include <syslog.h>
#include <string.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include "tcpsnoop.h"

/*-------------------------------------------------------------
 * Defaults
 --------------------------------------------------------------*/
 
 const char default_filename[] = "tcpshoot.log";
 const char default_server[] = "localhost";
 
 void dump_tcpinfo(struct tcp_info *info);
 
 /*-------------------------------------------------------------
 * Main Function
 --------------------------------------------------------------*/

int main(int argc, char **argv){
  /* Options with their defaults */
  unsigned short opt_buffer = DEFAULT_BUFFER;
  unsigned int opt_counter = DEFAULT_BYTES;
  char *opt_data = NULL;
  unsigned short opt_debug = 0;
  char *opt_filename = NULL;
  unsigned short opt_port = DEFAULT_PORT;
  char *opt_server = NULL;
  int option;
  
  /* File descriptors and data pointers */
  void *data = NULL;
  int datafd;
  void *position = NULL;
  FILE *statistics;
  
  /* Logic */
  static unsigned int bytecounter = 0;
  static double avg_bit_rate = 0.0;
  static double ALPHA = 0.6;
  
  /* Structures needed for measuring time intervals */
  static struct timeval time_start, time_now, time_delta, estimator_last_time;
  static unsigned int estimator_last_bytecounter = 0;
  
  /* TCP */
  static int tcp_socket;
  static struct sockaddr_in server_address;
  static struct hostent *server;
  static struct linger lingeropt;
  static struct tcp_info tcp_info;
  static int tcp_info_length;
  // int sndbuflen = DEFAULT_SOCKET_BUFFER_SND;
  int sndbuflen = 100;
  
  /* Set default options */
  opt_filename = (char *)default_filename;
  opt_server = (char *)default_server;
  
  /* Parse options*/
  while( (option = getopt(argc, argv, "b:x:c:d:D:f:hp:s")) != -1 ){
    switch( option ){
      case 'b':
          opt_buffer = ( unsigned short )( strtoul(optarg, NULL, 10) );
          if ( opt_buffer < MIN_BUFFER ){
            opt_buffer = MIN_BUFFER;
          }
          break;
      case 'x':
          sndbuflen = (int)( strtoul( optarg, NULL, 10 ) );
          fprintf(stderr, "Set SO_SNDBUF=%u\n",sndbuflen);
          break;
      case 'c':
          opt_counter = (unsigned int)( strtoul( optarg, NULL, 10 ) );
          if( opt_counter < MIN_BYTES ){
            opt_counter = MIN_BYTES;
          }
          break;
      case 'd':
          opt_data = optarg;
          break;
      case 'D':
          opt_debug = (unsigned short)( strtoul( optarg, NULL, 10 ) );
          break;
      case 'f':
          opt_filename = optarg;
          break;
      case 'h':
          puts("Welcome! This is tcpshoot.\n" \
               "Usage: tcpshoot [-b buffersize] [-c bytes] [-d datafile]\n" \
               "       [-D debug_level] [-f logfile] [-h] [-p port] [-s server] [-x snd_socket_buffer]\n");
          exit(EXIT_SUCCESS);
          break;
      case 'p':
          opt_port = (unsigned short)( strtoul( optarg, NULL, 10 ) );
          if(opt_port < 1024){
            puts("We don't connect to privileged ports!\n");
            exit(EXIT_FAILURE);
          }
          break;          
      case 's':
          opt_server = optarg;
          break;          
    }
  }
  
  /* If debug mode is enabled we print all options */
  if( opt_debug > 0 ){
    fprintf(stdout, "Debug mode enabled. Will use TCP buffer of size %u.\n" \
            "Will connect to server %s on port %u.\n" \
            "Will write %u bytes.\n",
            opt_buffer, opt_server, opt_port, opt_counter);
  }
  
  /* Resolve server's name */
  server = gethostbyname( opt_server );
  if( server == NULL ){
    fprintf(stderr, "Could not resolve server name!\n");
    exit(EXIT_FAILURE);
  }
  
  /* Open the file we log the parameters to. */
  statistics = fopen( opt_filename, "w+");
  if( statistics == NULL){
    fprintf(stderr, "Could not open statistics file: %s\n",strerror(errno));
    exit(EXIT_FAILURE);
  }
  
  /* Create a TCP socket */
  tcp_socket = socket( PF_INET, SOCK_STREAM, IPPROTO_TCP);
  if(tcp_socket == -1){
    fprintf(stderr, "Could not open TCP socket: %s\n",strerror(errno));
    exit(EXIT_FAILURE);
  }else{
    /* Creation of the socket was successful. We now set the SO_LINGER option
     * so that our close() call waits until all packets are sent successfully.
     * We tell the socket to wait 13 seconds after our buffers have been sent.
     */
    lingeropt.l_onoff = 1;
    lingeropt.l_linger = 13;
    if( setsockopt( tcp_socket, SOL_SOCKET, SO_LINGER,
                    (void *)&lingeropt, sizeof(lingeropt)    ) == -1 ){
      fprintf(stderr, "Could not set SO_LINGER option: %s\n\\"
                      "Closing the socket will happen in the background. \n", strerror(errno));
    }
    
    if(sndbuflen){
      if(setsockopt(tcp_socket, SOL_SOCKET, SO_SNDBUF, &sndbuflen, sizeof(sndbuflen)) < 0)
        fprintf(stderr,"SO_SNDBUF setsockopt error");
      
      int optlen = sizeof(sndbuflen);
      if(getsockopt(tcp_socket, SOL_SOCKET, SO_SNDBUF, &sndbuflen, &optlen) < 0)
        fprintf(stderr,"SO_SNDBUF getsockopt error");
      
      if(opt_debug > 0)
        fprintf(stderr,"SO_SNDBUF = %d\n", sndbuflen);
    }
    
    /* Prepare a sockaddr structure with the server's address and port number
     * and connect.
    */
    server_address.sin_family = AF_INET;
    memcpy(&server_address.sin_addr.s_addr, server->h_addr, server->h_length );
    server_address.sin_port = htons( opt_port);
    if( connect( tcp_socket, (struct sockaddr *)&server_address, sizeof(server_address) ) == -1 ){
      fprintf(stderr,"Could not connect to server: %s\n",strerror(errno));
      exit(EXIT_FAILURE);
    }  
  }

  /* Do we stream a file to a server? */
  if( opt_data != NULL ){
    /*Yes we do. So let's open it*/
    datafd = open( opt_data, O_RDONLY );
    if( datafd == -1 ){
      fprintf(stderr,"Could not open file '%s'! (%s)\n",opt_data,strerror(errno));
      exit(EXIT_FAILURE);
    }else{
      /* mmap file to memory for easier access. We don't need to copy buffers
       * around by taking advantage of this.
      */
      opt_counter = get_filesize(datafd);
      data = mmap( 0,opt_counter, PROT_READ, MAP_PRIVATE | MAP_NORESERVE, datafd, 0 );
      if( data == MAP_FAILED ){
        fprintf(stderr,"Can't map file '%s' to memory (%s)\n",opt_data,strerror(errno));
        close( datafd );
        close( tcp_socket );
      }
    }
  }else{
    /* Prepare memory buffer to be used with pseudorandom bytes and fill it with random data */
    data = malloc( opt_buffer );
    if( data == NULL ){
      fprintf(stderr,"Can't allocate buffer of %u bytes length!\n", opt_buffer);
      close( tcp_socket );
      exit(EXIT_FAILURE);
    }else{
      memset( data, rand(), opt_buffer );
    }
  }

  /*---------------------------------------------------------------------------
   * Our main loop where we send the data and write to the statistics file
   *--------------------------------------------------------------------------*/
  
  /* Mark start of transmission in log file */
  if( opt_data == NULL ){
    fprintf(statistics, "time mss cwnd ssthresh unacked rtt rttvar rto retrans Mbytes kbps(bits/time) Kbps(cwnd/rtt)\n");
  }else{
    fprintf(statistics, "time mss cwnd ssthresh unacked rtt rttvar rto retrans Mbytes kbps(bits/time) Kbps(cwnd/rtt)\n");
  }

  /* position is our pointer to the current position in the data buffer. This is
   * only important when streaming a file since we have to move along the mmapped
   * memory region in steps of opt_counter bytes.
   */
  position = data;
  /* Stopwatch time */
  get_now( &estimator_last_time, 1 );
  get_now( &time_start, 1 );
  while( bytecounter <= opt_counter ){
    /* Send first portion of data */
    if( send( tcp_socket, position, opt_buffer, 0 ) == -1 ){
      fprintf(stderr, "Error '%s' while sending %u bytes.\n", strerror(errno), opt_buffer);
    }
    /* Refill the buffer or move the position pointer */
    if( opt_data != NULL ){
      position += opt_buffer;
    }else{
      memset( data, rand(), opt_buffer );
    }
    bytecounter += opt_buffer;
    
    /* Meaasure time in order to create time intervals */
    get_now( &time_now, 1 );
    /* Get struct tcp_info and extract parameters */
    tcp_info_length = sizeof(tcp_info);
    if( getsockopt( tcp_socket, SOL_TCP, TCP_INFO, (void *)&tcp_info, (socklen_t *)&tcp_info_length ) == 0 ){
      double relative_time = time_to_seconds( &time_start, &time_now );
      
      /* Init estimator */
      if( avg_bit_rate == 0.0 ){
        /* First time */
        estimator_last_time = time_now;
        estimator_last_bytecounter = bytecounter;
        avg_bit_rate = 0.001;
      }
      /* Update estimator */
      else{
        if( time_to_seconds(&estimator_last_time, &time_now) > (tcp_info.tcpi_rto*1e-6) ){
          avg_bit_rate = ALPHA * avg_bit_rate + (1.0 - ALPHA) * ((bytecounter - estimator_last_bytecounter)*8.0/1000.0/time_to_seconds( &estimator_last_time, &time_now ));
          estimator_last_time = time_now;
          estimator_last_bytecounter = bytecounter;
        }
      }
      
      /* Write parameters to file. */
      if( opt_debug == 1 ){
        fprintf( stdout, "%.6f \tMBsend = %.2f \t bitrate (send/time) = %.1f Kbps \t bitrate(cwnd/RTT) = %.1f Kbps\n", 
                 relative_time, bytecounter/1048576.0, avg_bit_rate, 1000.0*(tcp_info.tcpi_snd_mss*8.0*tcp_info.tcpi_snd_cwnd)/(double)tcp_info.tcpi_rtt );
      }
      
      if( opt_debug > 1 ){
        fprintf( stdout, "%.6f \tMBsend = %.2f \t bitrate (send/time) = %.1f Kbps \t bitrate(cwnd/RTT) = %.1f Kbps \tcwnd = %u \tRTT(ms) = %.1f \t RTO = %.1f\tRetrans=%u\n", 
                 relative_time, bytecounter/1048576.0, avg_bit_rate, 1000.0*(tcp_info.tcpi_snd_mss*8.0*tcp_info.tcpi_snd_cwnd)/(double)tcp_info.tcpi_rtt, tcp_info.tcpi_snd_cwnd, tcp_info.tcpi_rtt/1000.0, tcp_info.tcpi_rto/1000.0, tcp_info.tcpi_total_retrans );
      }
      
      if( opt_debug > 2 ){
        fprintf( stderr, "\n%.6f ms________________________________\n", relative_time );
        dump_tcpinfo(&tcp_info);
      }
      
      fprintf( statistics, "",
               relative_time,
               tcp_info.tcpi_snd_mss,
               tcp_info.tcpi_snd_cwnd,
               tcp_info.tcpi_snd_ssthresh,
               tcp_info.tcpi_unacked,
               tcp_info.tcpi_rtt,
               tcp_info.tcpi_rttvar,
               tcp_info.tcpi_rto,
               tcp_info.tcpi_total_retrans,
               bytecounter/1048576.0,
               avg_bit_rate,
               1000.0*(tcp_info.tcpi_snd_mss*8.0*tcp_info.tcpi_snd_cwnd)/(double)tcp_info.tcpi_rtt
             );
    }
  }

  /* We've done it. Free all resources. */
  close( tcp_socket );
  if( opt_data == NULL ){
    free( data );
  }else{
    if( munmap( data, opt_counter ) == -1 ){
      fprintf(stderr, "Error while unmapping the data file '%s'. \n", opt_data);
    }
    close( datafd );
  }
  fputs("\n\n\n",statistics);
  fclose( statistics );
  exit(EXIT_SUCCESS);
}

/* dump tcp info */
void dump_tcpinfo(struct tcp_info *info){
  fprintf(stderr, "  tcpi_state ............: %u\n", info->tcpi_state);
  fprintf(stderr, "  tcpi_ca_state .........: %u\n", info->tcpi_ca_state);
  fprintf(stderr, "  tcpi_retransmits ......: %u\n", info->tcpi_retransmits);
  fprintf(stderr, "  tcpi_probes ...........: %u\n", info->tcpi_probes);
  fprintf(stderr, "  tcpi_backoff ..........: %u\n", info->tcpi_backoff);
  fprintf(stderr, "  tcpi_options ..........: %u\n", info->tcpi_options);
  fprintf(stderr, "  tcpi_snd_wscale .......: %u\n", info->tcpi_snd_wscale);
  fprintf(stderr, "  tcpi_rcv_wscale .......: %u\n", info->tcpi_rcv_wscale);
  fprintf(stderr, "  tcpi_rto ..............: %u\n", info->tcpi_rto);
  fprintf(stderr, "  tcpi_ato ..............: %u\n", info->tcpi_ato);
  fprintf(stderr, "  tcpi_snd_mss ..........: %u\n", info->tcpi_snd_mss);
  fprintf(stderr, "  tcpi_rcv_mss ..........: %u\n", info->tcpi_rcv_mss);
  fprintf(stderr, "  tcpi_unacked ..........: %u\n", info->tcpi_unacked);
  fprintf(stderr, "  tcpi_sacked ...........: %u\n", info->tcpi_sacked);
  fprintf(stderr, "  tcpi_lost .............: %u\n", info->tcpi_lost);
  fprintf(stderr, "  tcpi_retrans ..........: %u\n", info->tcpi_retrans);
  fprintf(stderr, "  tcpi_fackets ..........: %u\n", info->tcpi_fackets);
  fprintf(stderr, "  Times :\n");
  fprintf(stderr, "    tcpi_last_data_sent .: %u\n", info->tcpi_last_data_sent);
  fprintf(stderr, "    tcpi_last_ack_sent ..: %u\n", info->tcpi_last_ack_sent);
  fprintf(stderr, "    tcpi_last_data_recv .: %u\n", info->tcpi_last_data_recv);
  fprintf(stderr, "    tcpi_last_ack_recv ..: %u\n", info->tcpi_last_ack_recv);
  fprintf(stderr, "  Metrics :\n");
  fprintf(stderr, "    tcpi_pmtu ...........: %u\n", info->tcpi_pmtu);
  fprintf(stderr, "    tcpi_rcv_ssthresh ...: %u\n", info->tcpi_rcv_ssthresh);
  fprintf(stderr, "    tcpi_rtt ............: %u\n", info->tcpi_rtt);
  fprintf(stderr, "    tcpi_rttvar .........: %u\n", info->tcpi_rttvar);
  fprintf(stderr, "    tcpi_snd_ssthresh ...: %u\n", info->tcpi_snd_ssthresh);
  fprintf(stderr, "    tcpi_snd_cwnd .......: %u\n", info->tcpi_snd_cwnd);
  fprintf(stderr, "    tcpi_advmss .........: %u\n", info->tcpi_advmss);
  fprintf(stderr, "    tcpi_reordering .....: %u\n", info->tcpi_reordering);
  fprintf(stderr, "    tcpi_rcv_rtt ........: %u\n", info->tcpi_rcv_rtt);
  fprintf(stderr, "    tcpi_rcv_space ......: %u\n", info->tcpi_rcv_space);
  fprintf(stderr, "    tcpi_total_retrans ..: %u\n", info->tcpi_total_retrans);
}