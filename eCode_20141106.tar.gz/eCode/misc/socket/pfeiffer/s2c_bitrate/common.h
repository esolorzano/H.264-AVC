#include <stdio.h>      /* for printf() and fprintf() */
#include <sys/socket.h> /* for socket(), bind(), and connect() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_ntoa() */
#include <stdlib.h>     /* for atoi() and exit() */
#include <string.h>     /* for memset() */
#include <unistd.h>     /* for close() */
#include <sys/types.h>

#include <netdb.h>
#include <string.h>

#include <sys/time.h>
#include <time.h>

#define DEFAULT_PORT 8080
#define DEFAULT_SERVER "localhost"
#define BUFSIZE 1024*4

typedef struct{
  struct timeval tvBegin;
  struct timeval tvEnd;
  struct timeval tvDiff;
} times_t;


int setaddrbyname(struct sockaddr_in *addr, char *host);
int timeval_subtract(struct timeval *result, struct timeval *t2, struct timeval *t1);
float calculateRate(int sizeData, struct timeval diff);
void getPeriodTime(times_t *times, char option);