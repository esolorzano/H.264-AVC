#include <sys/time.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>


typedef struct{
  struct timeval tvBegin;
  struct timeval tvEnd;
  struct timeval tvDiff;
  double dBitrateM;
} speed_t;


// Return 1 if the difference is negative, otherwise 0.
int timeval_subtract(struct timeval *result, struct timeval *t2, struct timeval *t1)
{
    long int diff = (t2->tv_usec + 1000000 * t2->tv_sec) - (t1->tv_usec + 1000000 * t1->tv_sec);
    result->tv_sec = diff / 1000000;
    result->tv_usec = diff % 1000000;

    return (diff<0);
}

void timeval_print(struct timeval *tv)
{
    char buffer[30];
    time_t curtime;

    printf("%ld.%06ld", tv->tv_sec, tv->tv_usec);
    curtime = tv->tv_sec;
    strftime(buffer, 30, "%m-%d-%Y  %T", localtime(&curtime));
    printf(" = %s.%06ld\n", buffer, tv->tv_usec);
}

float calculateRate(int sizeData, struct timeval diff){
  return 8*sizeData/((float)diff.tv_sec + (float)diff.tv_usec/1000000);
}

void calculateBitrate(speed_t *speed, int option){
  struct timeval* tvBegin = &(speed->tvBegin);
  struct timeval* tvEnd = &(speed->tvEnd);
  struct timeval* tvDiff = &(speed->tvDiff);
  
  switch(option){
    case 0:
      break;
    case 1: /* begin */
      gettimeofday(tvBegin, NULL);
      break;
    case 2: /* end */
      gettimeofday(tvEnd, NULL);
      timeval_subtract(tvDiff, tvEnd, tvBegin);
      break;
  }
}


int main()
{

    speed_t speed;
    struct timeval tvBegin, tvEnd, tvDiff;

    // begin
    // gettimeofday(&tvBegin, NULL);
    calculateBitrate(&speed,1);
    timeval_print(&(speed.tvBegin));

    // lengthy operation
    int i,j;
    for(i=0;i<999999L;++i) {
    	j=sqrt(i);
    }
    

    //end
    // gettimeofday(&tvEnd, NULL);
    calculateBitrate(&speed,2);
    timeval_print(&(speed.tvEnd));

    // diff
    // timeval_subtract(&tvDiff, &tvEnd, &tvBegin);
    tvDiff = speed.tvDiff;
    printf("%ld.%06ld\n", tvDiff.tv_sec, tvDiff.tv_usec);

    return 0;
}


