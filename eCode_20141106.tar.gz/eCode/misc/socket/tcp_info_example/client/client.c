#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h> 

#include <netinet/tcp.h>

void print_socketOptios(int sockfd);

int main(int argc, char *argv[])
{
  
    int sockfd = 0, n = 0;
    char recvBuff[1024];
    struct sockaddr_in serv_addr; 

    if(argc != 2)
    {
        printf("\n Usage: %s <ip of server> \n",argv[0]);
        return 1;
    } 

    memset(recvBuff, '0',sizeof(recvBuff));
    if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        printf("\n Error : Could not create socket \n");
        return 1;
    } 

    memset(&serv_addr, '0', sizeof(serv_addr)); 

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(5000); 

    if(inet_pton(AF_INET, argv[1], &serv_addr.sin_addr)<=0)
    {
        printf("\n inet_pton error occured\n");
        return 1;
    } 

    if( connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
       printf("\n Error : Connect Failed \n");
       return 1;
    } 
    
    print_socketOptios(sockfd); //TEST

    while ( (n = read(sockfd, recvBuff, sizeof(recvBuff)-1)) > 0)
    {
        recvBuff[n] = 0;
        if(fputs(recvBuff, stdout) == EOF)
        {
            printf("\n Error : Fputs error\n");
        }
    } 

    print_socketOptios(sockfd); //TEST
    
    if(n < 0)
    {
        printf("\n Read error \n");
    } 

    return 0;
}

void print_socketOptios(int sockfd){
  struct tcp_info info;
  socklen_t optlen;
  int res = 0;
  optlen = sizeof(info);
  res = getsockopt(sockfd, SOL_TCP, TCP_INFO, &info, &optlen); 
  if(res == -1)
    printf("Error getsockopt tcp_info");
  else{
     // printf("send buffer size = %d\n", sendbuff);     
    printf("info.tcpi_state = %d\n", info.tcpi_state);     
    printf("info.tcpi_ca_state = %d\n", info.tcpi_ca_state);  
    printf("info.tcpi_retransmits = %d\n", info.tcpi_retransmits);
    printf("info.tcpi_probes = %d\n", info.tcpi_probes);
    printf("info.tcpi_backoff = %d\n", info.tcpi_backoff);
    printf("info.tcpi_options = %d\n", info.tcpi_options);
    printf("info.tcpi_snd_wscale = %d\n", info.tcpi_snd_wscale);
    printf("info.tcpi_rcv_wscale = %d\n", info.tcpi_rcv_wscale);
    printf("info.tcpi_rto = %d\n", info.tcpi_rto);
    printf("info.tcpi_ato = %d\n", info.tcpi_ato);
    printf("info.tcpi_snd_mss = %d\n", info.tcpi_snd_mss);
    printf("info.tcpi_rcv_mss = %d\n", info.tcpi_rcv_mss);
    printf("info.tcpi_unacked = %d\n", info.tcpi_unacked);
    printf("info.tcpi_sacked = %d\n", info.tcpi_sacked);
    printf("info.tcpi_lost = %d\n", info.tcpi_lost);
    printf("info.tcpi_retrans = %d\n", info.tcpi_retrans);
    printf("info.tcpi_fackets = %d\n", info.tcpi_fackets);
    printf("info.tcpi_last_data_sent = %d\n", info.tcpi_last_data_sent);
    printf("info.tcpi_last_ack_sent = %d\n", info.tcpi_last_ack_sent);
    printf("info.tcpi_last_data_recv = %d\n", info.tcpi_last_data_recv);
    printf("info.tcpi_last_ack_recv = %d\n", info.tcpi_last_ack_recv);
    printf("info.tcpi_pmtu = %d\n", info.tcpi_pmtu);
    printf("info.tcpi_rcv_ssthresh = %d\n", info.tcpi_rcv_ssthresh);
    printf("info.tcpi_rtt = %d\n", info.tcpi_rtt);
    printf("info.tcpi_rttvar = %d\n", info.tcpi_rttvar);
    printf("info.tcpi_snd_ssthresh = %d\n", info.tcpi_snd_ssthresh);
    printf("info.tcpi_snd_cwnd = %d\n", info.tcpi_snd_cwnd);
    printf("info.tcpi_advmss = %d\n", info.tcpi_advmss);
    printf("info.tcpi_reordering = %d\n", info.tcpi_reordering);     
  }

     
}
