#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h> 

#include <netinet/tcp.h>

#define BUFSIZE 32

float getThr(int sockfd);

int main(int argc, char *argv[])
{
    FILE* fin; 
    int n;
    
    int listenfd = 0, connfd = 0;
    struct sockaddr_in serv_addr; 

    char sendBuff[BUFSIZE];
    time_t ticks; 

    listenfd = socket(AF_INET, SOCK_STREAM, 0);
    memset(&serv_addr, '0', sizeof(serv_addr));
    memset(sendBuff, '0', sizeof(sendBuff)); 

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(5000); 

    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)); 

    listen(listenfd, 10); 
    
    if(argc < 2){ printf("uso: %s <file>\n",argv[0]); return 1;}
    else{
      fin = fopen(argv[1], "r");
    }

    while(1)
    {
        connfd = accept(listenfd, (struct sockaddr*)NULL, NULL); 

        do{
          n = fread(sendBuff,1,(1 +  rand()%BUFSIZE),fin);
          write(connfd, sendBuff, n);
          sleep(1);
          float T = getThr(connfd);
          printf("enviando...%d bytes |T: %f\n",n,T);
          
        }while(n!=0);
        
        rewind(fin);

        close(connfd);
        sleep(5);
     }
}

float getThr(int sockfd){
  struct tcp_info info;
  socklen_t optlen;
  int res = 0;
  optlen = sizeof(info);
  res = getsockopt(sockfd, SOL_TCP, TCP_INFO, &info, &optlen); 
  if(res == -1)
    printf("Error getsockopt tcp_info");
  else{
    // return (1000*info.tcpi_snd_cwnd/info.tcpi_rtt);
    return (1000*(float)info.tcpi_snd_cwnd/(float)info.tcpi_rttvar);
  }

  return -1.0;
}