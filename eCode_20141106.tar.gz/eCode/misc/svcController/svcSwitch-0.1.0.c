/**
	@author	Edwin Solorzano <solorzano.em@gmail.com>
	@data	2013-08-20
	@file	svcSwitch.c
	@brief	Switch between different H264 input streams  in order to adapt output strem to medium.
  @version  0.1.0
*/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "../h264bitstream-0.1.10/bs.h"
#include "../h264bitstream-0.1.10/h264_stream.h"

/**
  @def NUM_STREAMS
    numero de input streams H264 que se usar�n para generar un output stream H264
    
 @def BUFSIZE
    logintud del buffer de lectura del bitstream de entrada
*/

#define NUM_STREAMS 2
#define BUFSIZE 128*1024*1024 //128MB
#define testPASS()  printf("%d @ %s()......\n",__LINE__,__FUNCTION__)

typedef struct
{
  FILE* fs;
  char infilename[200];
  
  uint8_t* buf;
  uint8_t* p;
  uint8_t* p_dump;
  int nal_start;
  int nal_end;
  size_t rsz;
  size_t sz;
  int64_t off;
  int leido;
    
  h264_stream_t* h;  
  
  int first_load;
  int nu_index;
  
  uint8_t* p_slice_I_data;
  int p_slice_I_size;
  
} stream_read_vars_t;

void init_stream_read_vars(stream_read_vars_t* stream_read_vars);
void free_stream_read_vars(stream_read_vars_t* stream_read_vars);
int read_nal(stream_read_vars_t* srv);
int getMin(stream_read_vars_t* stream_read_vars);

int main(int argc, char *argv[]){

  stream_read_vars_t srv[NUM_STREAMS];
  init_stream_read_vars(srv);

  //validaci�n de par�metros
  if(argc<3){ //modificar cuando se aumente el numero de input streams obligatorios
    printf("uso correcto: \n");
    printf("\t./svcSwitch <stream_0_264> <stream_1_264> \n\n");
    free_stream_read_vars(srv);
    return 1;
  }else{
    strcpy(srv[0].infilename,argv[1]);
    strcpy(srv[1].infilename,argv[2]);    
  }

  //apertura de input streams
  
  for(int i=0;i<NUM_STREAMS;i++){
    srv[i].fs = fopen(srv[i].infilename,"rb");
    if(!srv[i].fs){
      printf("no se pudo abrir el fichero: [%s]\n",srv[i].infilename);
      return 1;
    }   
  }
  
  //Lectura de input streams y dosificacion en el output stream
  FILE* fsout = fopen("out.264","wb");
  uint8_t separator[4] = {0,0,0,1};
  int suma = 0;
  int seguir_lectura = 0;
  int k = 0;
  int contador;
  do{
    seguir_lectura = 0;
    suma = 0;
    //para alinear las NAL unit leidas
    for(int i=0;i<NUM_STREAMS;i++) suma += srv[i].nu_index;
    int media = suma*1000/NUM_STREAMS;
    if((media%1000) == 0){ //estan alineadas
      for(int i=0;i<NUM_STREAMS;i++){ 
        srv[i].leido = read_nal(&srv[i]);
      }
    }else{ //no estan alineadas, alinear
      int index = getMin(srv);
      srv[index].leido = read_nal(&srv[index]);
    }

    //------------- DEVELOP INIT --------
    // int s0 = srv[0].nal_end-srv[0].nal_start; //TEST
    // int s1 = srv[1].nal_end-srv[1].nal_start; //TEST         
    // printf("%d: (%d)(%d)|size0[%X] - size1[%X] | k: %d\n",__LINE__,srv[0].nu_index,srv[1].nu_index,s0,s1,k); //TEST    
    
    
    
    //discriminador
    k=(contador++ < 2000)?0:1;
    
    h264_stream_t* h = srv[k].h;    

    // if(h->nal->nal_unit_type == NAL_UNIT_TYPE_CODED_SLICE_NON_IDR){
    if(h->nal->nal_unit_type == NAL_UNIT_TYPE_AUD){
      slice_header_t* sh = h->sh;
      // if(sh->pic_order_cnt_lsb == 0)
      // if(sh->slice_type == 2 && sh->pic_order_cnt_lsb == 0)
      // if(sh->slice_type == 9)
        // printf("%d(%4d)| nal_unit_type : %d \n",k,contador,h->nal->nal_unit_type); //TEST
        
      printf("%d(%4d) \n",k,contador); //TEST
    }    
    
    // escritura en el output stream
    fwrite(separator,1,4,fsout); 
    fwrite(srv[k].p_dump,1,srv[k].nal_end - srv[k].nal_start,fsout);
    
    //------------- DEVELOP END --------
    
    for(int l=0;l<NUM_STREAMS;l++) seguir_lectura = seguir_lectura || srv[l].leido;
  }while(seguir_lectura);

  //separador final;
  fwrite(separator,1,4,fsout);
  
  // Cerrar streams y Liberar memoria
  for(int i=0;i<NUM_STREAMS;i++)
    fclose(srv[i].fs);
  
  free_stream_read_vars(srv);
  printf("\n ----------------------- FIN ----------------------- \n");
  return 0;
}

/**
  Lectura de una NAL unit de uno de los input streams
*/
int read_nal(stream_read_vars_t* srv)
{
  uint8_t* buf = srv->buf;
  uint8_t** p = &srv->p;
  uint8_t** p_dump = &srv->p_dump;
  int* nal_start = &srv->nal_start;
  int* nal_end = &srv->nal_end;
  size_t* rsz = &srv->rsz;
  size_t* sz = &srv->sz;
  int64_t* off = &srv->off;    
  h264_stream_t* h = srv->h;
  FILE* fsin = srv->fs;
  int* first_load = &srv->first_load;

  if(*first_load){
    *rsz = fread(buf + *sz, 1, BUFSIZE - *sz, fsin);
    *first_load = 0;
    *sz += *rsz;
  }
  if (*rsz == 0)
  {
    if (ferror(fsin)) { fprintf( stderr, "!! Error: read failed: %s \n", strerror(errno)); return *rsz; }
    return *rsz;  // if (feof(fsin)) 
  }

  int is_there_nal = find_nal_unit(*p, *sz, nal_start, nal_end);
  if ( is_there_nal > 0)
  {
      srv->nu_index++;   
      
      *p += *nal_start;
      read_nal_unit(h, *p, *nal_end - *nal_start);
      // debug_bytes(*p,*nal_end - *nal_start); //TEST
      *p_dump = *p;
      *p += (*nal_end - *nal_start);
      *sz -= *nal_end;
  }else{

    // printf("*");//TEST
    
    memmove(buf, *p, *sz);
    *off += *p - buf;
    *p = buf;    
    
    *rsz = fread(buf + *sz, 1, BUFSIZE - *sz, fsin); 
    *sz += *rsz;
    return *rsz;
  }
  // if no NALs found in buffer, discard it
  if (*p == buf) 
  {
      fprintf( stderr, "!! Did not find any NALs between offset %lld (0x%04llX), size %lld (0x%04llX), discarding \n",
             (long long int)*off, 
             (long long int)*off, 
             (long long int)*off + *sz, 
             (long long int)*off + *sz);

      *p = buf + *sz;
      *sz = 0;
  }
  
  return *rsz;
}


/**
  Reservar e inicializar los espacio de memoria para cada input stream
*/
void init_stream_read_vars(stream_read_vars_t* stream_read_vars){
  stream_read_vars_t* srv;
  for(int i=0;i<NUM_STREAMS;i++){
    srv = stream_read_vars + i;
    srv->buf = (uint8_t*)malloc( BUFSIZE );
    srv->p = srv->buf;
    srv->p_dump = srv->buf;
    srv->h = h264_new();
    srv->rsz = 0;
    srv->sz = 0;
    srv->off = 0;
    srv->first_load = 1;
    srv->nu_index = 0;
    srv->leido = 0;
    
    srv->p_slice_I_data = (uint8_t*)malloc( 1*1024*1024 );
    srv->p_slice_I_size = 0;
  }
}

/**
  Liberar memoria
*/
void free_stream_read_vars(stream_read_vars_t* stream_read_vars){
  stream_read_vars_t* srv;
  for(int i=0;i<NUM_STREAMS;i++){
    srv = stream_read_vars + i;
    free(srv->buf);
    h264_free(srv->h);
  }
}

/**
  Determina qu� input stream tiene el menor numero de NAL units leidas
*/
int getMin(stream_read_vars_t* srv)
{
  int min = 1*1*1024*1024;
  int index = 0;
  for(int i=0;i<NUM_STREAMS;i++){
    if(srv[i].nu_index<min){ 
      min = srv[i].nu_index;
      index = i;
    }
  }  
  return index;
}