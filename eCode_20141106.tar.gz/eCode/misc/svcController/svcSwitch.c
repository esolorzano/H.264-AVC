/**
	@author	Edwin Solorzano <solorzano.em@gmail.com>
	@data	2013-09-04
	@file	svcSwitch.c
	@brief	Switch between different H264 input streams  in order to adapt output strem to medium.
  @version  0.1.2
*/

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include "../h264bitstream-0.1.10/bs.h"
#include "../h264bitstream-0.1.10/h264_stream.h"

#include "../inih/ini.h"

/**
    
 @def BUFSIZE
    logintud del buffer de lectura del bitstream de entrada
*/

#define BUFSIZE 128*1024*1024 //128MB
#define testPASS()  printf("%d @ %s()......\n",__LINE__,__FUNCTION__)

int NUM_STREAMS = 6; //�ste valor cambia cuando se carga el fichero de inicializaci�n

typedef struct
{
    const char* pathIN;
    const char* inputs;
    const char* output;
    const char* capFile;
    
    // al agregar un par�metro aqui tambien se debe actualizar la funcion handler()
} configuration; 


typedef struct
{
  FILE* fs;
  char infilename[200];
  
  uint8_t* buf;
  uint8_t* p;
  uint8_t* p_dump;
  int nal_start;
  int nal_end;
  size_t rsz;
  size_t sz;
  int64_t off;
  int leido;
    
  h264_stream_t* h;  
  
  int first_load;
  int nu_index;
  
  uint8_t* p_slice_I_data;
  int p_slice_I_size;
  
  long int kbps_gop;
  
} stream_read_vars_t;

void init_stream_read_vars(stream_read_vars_t* stream_read_vars);
void free_stream_read_vars(stream_read_vars_t* stream_read_vars);
int read_nal(stream_read_vars_t* srv);
int getMin(stream_read_vars_t* stream_read_vars);
struct timespec diff(struct timespec start, struct timespec end);
int loadCapacity(char* capacityFile,int* upCapacity_kbps, int* downCapacity_kbps);

static int handler(void* user, const char* section, const char* name, const char* value);


int main(int argc, char *argv[]){
  stream_read_vars_t srv[NUM_STREAMS];
  init_stream_read_vars(srv);
  char* outputFile;  
  configuration config;
  
  int gop_size = 0;
  int upCapacity_kbps=0, downCapacity_kbps=0;
  long int kbps = 0; //0kbps
  

  //Carga de configuracion
  if (ini_parse("file.ini", handler, &config) < 0) {
      printf("No se pudo cargar la configuration de 'file.ini'\n");
      return 1;
  }

  char* pch;
  int cnt = 0;
  pch = strtok((char *)config.inputs, " ,");
  while (pch != NULL)
  {
    strcpy(srv[cnt].infilename, config.pathIN);
    strcat(srv[cnt].infilename, pch);    
    cnt++;
    pch = strtok (NULL, " ,");    
  }     
  NUM_STREAMS = (cnt<5)?cnt:4;
  
  printf("se procesaran %d ficheros\n",NUM_STREAMS);
  
  outputFile = strdup(config.output);
  if(loadCapacity((char*)config.capFile,&upCapacity_kbps, &downCapacity_kbps)){
    printf("No se pudo cargar el valor de la capacidad del canal\n\n");
    return 1;
  }
  
  if(upCapacity_kbps == 0){ 
    printf("no hay canales disponibles para transmitir -> up = %dkbps\n\n", upCapacity_kbps);
    return 1;
  }
  printf("capacidad actual: up[%d] - down[%d]\n",upCapacity_kbps,downCapacity_kbps);

  //apertura de input/output streams
  
  for(int i=0;i<NUM_STREAMS;i++){
    srv[i].fs = fopen(srv[i].infilename,"rb");
    if(!srv[i].fs){
      printf("no se pudo abrir el fichero: [%s]\n",srv[i].infilename);
      return 1;
    }   
  }
  
  FILE* fsout = fopen(outputFile,"wb");
  if(!fsout){
    printf("no se pudo abrir el fichero: [%s]\n",outputFile);
    return 1;
  }  
  
  //Lectura de input streams y dosificacion en el output stream
  uint8_t separator[4] = {0,0,0,1};
  int suma = 0;
  int seguir_lectura = 0;
  unsigned int k = 0;
  int contador = 0;
  int cambia_k = 0;
  do{
    seguir_lectura = 0;
    suma = 0;
    //para alinear las NAL unit leidas
    for(int i=0;i<NUM_STREAMS;i++) suma += srv[i].nu_index;
    int media = suma*1000/NUM_STREAMS;
    if((media%1000) == 0){ //estan alineadas
      for(int i=0;i<NUM_STREAMS;i++){ 
        srv[i].leido = read_nal(&srv[i]);
      }
    }else{ //no estan alineadas, alinear
      int index = getMin(srv);
      srv[index].leido = read_nal(&srv[index]);
    }

    //------------- CONTROL UNIT --------
    
    h264_stream_t* h = srv[k].h;
    if(h->nal->nal_unit_type == NAL_UNIT_TYPE_AUD){ //inicio de GOP
      if(cambia_k){
        srv[k].kbps_gop = (gop_size*8)/1000;
        if(srv[k].kbps_gop < upCapacity_kbps) k=(k<(NUM_STREAMS-1))?++k:k;
        else k=(k > 0)?--k:k;      
      }
      cambia_k = 1;
      printf("Q:%d (frame %4d) - pack (%6d)bytes @ (%6li)kbps |Channel: up[%5d]kbps\n",k,contador++,gop_size,srv[k].kbps_gop,upCapacity_kbps); //TEST
      gop_size = 0;
    }    
    
    // escritura en el output stream
    gop_size += srv[k].nal_end - srv[k].nal_start; 
    fwrite(separator,1,4,fsout); 
    fwrite(srv[k].p_dump,1,srv[k].nal_end - srv[k].nal_start,fsout);
    
    //------------- CONTROL END --------
    
    for(int l=0;l<NUM_STREAMS;l++) seguir_lectura = seguir_lectura || srv[l].leido;
  }while(seguir_lectura);

  //separador final;
  fwrite(separator,1,4,fsout);
  
  // Cerrar streams y Liberar memoria
  for(int i=0;i<NUM_STREAMS;i++)
    fclose(srv[i].fs);
  
  free_stream_read_vars(srv);
  printf("\n ----------------------- FIN ----------------------- \n");
  return 0;
}

/**
 *  @brief Lectura de una NAL unit de uno de los input streams
 *  
 *  @param [in,out] srv estado de los streams leidos.
 *  @return 0 si se lleg� al final del stream, caso contrario el numero de bytes leidos.
 *  
 */
int read_nal(stream_read_vars_t* srv)
{
  uint8_t* buf = srv->buf;
  uint8_t** p = &srv->p;
  uint8_t** p_dump = &srv->p_dump;
  int* nal_start = &srv->nal_start;
  int* nal_end = &srv->nal_end;
  size_t* rsz = &srv->rsz;
  size_t* sz = &srv->sz;
  int64_t* off = &srv->off;    
  h264_stream_t* h = srv->h;
  FILE* fsin = srv->fs;
  int* first_load = &srv->first_load;
  long int* kbps_gop = &srv->kbps_gop;

  if(*first_load){
    *rsz = fread(buf + *sz, 1, BUFSIZE - *sz, fsin);
    *first_load = 0;
    *sz += *rsz;
  }
  if (*rsz == 0)
  {
    if (ferror(fsin)) { fprintf( stderr, "!! Error: read failed: %s \n", strerror(errno)); return *rsz; }
    return *rsz;  // if (feof(fsin)) 
  }

  int is_there_nal = find_nal_unit(*p, *sz, nal_start, nal_end);
  if ( is_there_nal > 0)
  {
      srv->nu_index++;   
      
      *p += *nal_start;
      read_nal_unit(h, *p, *nal_end - *nal_start);
      // debug_bytes(*p,*nal_end - *nal_start); //TEST
      *p_dump = *p;
      *p += (*nal_end - *nal_start);
      *sz -= *nal_end;
  }else{

    // printf("*");//TEST
    
    memmove(buf, *p, *sz);
    *off += *p - buf;
    *p = buf;    
    
    *rsz = fread(buf + *sz, 1, BUFSIZE - *sz, fsin); 
    *sz += *rsz;
    return *rsz;
  }
  // if no NALs found in buffer, discard it
  if (*p == buf) 
  {
      fprintf( stderr, "!! Did not find any NALs between offset %lld (0x%04llX), size %lld (0x%04llX), discarding \n",
             (long long int)*off, 
             (long long int)*off, 
             (long long int)*off + *sz, 
             (long long int)*off + *sz);

      *p = buf + *sz;
      *sz = 0;
  }
  
  return *rsz;
}


/**
 *  @brief Reservar e inicializar los espacio de memoria para cada input stream
 *  
 *  @param [out] estado de los streams leidos
 *  
 */
void init_stream_read_vars(stream_read_vars_t* stream_read_vars){
  stream_read_vars_t* srv;
  for(int i=0;i<NUM_STREAMS;i++){
    srv = stream_read_vars + i;
    srv->buf = (uint8_t*)malloc( BUFSIZE );
    srv->p = srv->buf;
    srv->p_dump = srv->buf;
    srv->h = h264_new();
    srv->rsz = 0;
    srv->sz = 0;
    srv->off = 0;
    srv->first_load = 1;
    srv->nu_index = 0;
    srv->leido = 0;
    
    srv->p_slice_I_data = (uint8_t*)malloc( 1*1024*1024 );
    srv->p_slice_I_size = 0;
    
    srv->kbps_gop = 0;
  }
}

/**
 *  @brief Liberar memoria utilizada por el estado de los streams
 *  
 *  @param [in] stream_read_vars Parameter_Description
 */
void free_stream_read_vars(stream_read_vars_t* stream_read_vars){
  stream_read_vars_t* srv;
  for(int i=0;i<NUM_STREAMS;i++){
    srv = stream_read_vars + i;
    free(srv->buf);
    h264_free(srv->h);
  }
}

/**
 *  @brief Determina qu� input stream tiene el menor numero de NAL units leidas.
 *  
 *  @param [in] srv estado de los streams leidos
 *  @return retorna el identificador del stream.
 */
int getMin(stream_read_vars_t* srv)
{
  int min = 1*1*1024*1024;
  int index = 0;
  for(int i=0;i<NUM_STREAMS;i++){
    if(srv[i].nu_index<min){ 
      min = srv[i].nu_index;
      index = i;
    }
  }  
  return index;
}

/**
  Determina la diferencia de tiempo
*/
struct timespec diff(struct timespec start, struct timespec end)
{
	struct timespec temp;
	if(end.tv_sec>=start.tv_sec){
		if(end.tv_nsec>=start.tv_nsec){
			temp.tv_sec = end.tv_sec-start.tv_sec;
			temp.tv_nsec = end.tv_nsec-start.tv_nsec;
		}else{
			temp.tv_sec = end.tv_sec-start.tv_sec-1;
			temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
		}
	}else{
		temp.tv_sec = 0;
		temp.tv_nsec = 0;
	}

	return temp;
}

/**
  Carga las capacidades de UpLoad y DownLoad actuales  
*/
int loadCapacity(char* capacityFile,int* upCapacity_kbps, int* downCapacity_kbps)
{
  int n;
  size_t len=0;
  char* buff;
  char* ch;
  FILE* fd = fopen(capacityFile,"r");

  if(!fd){
    printf("no se pudo abrir el fichero: [%s], \nrevise el valor del campo 'capFile' del fichero de inicializacion \n",capacityFile);
    return 1;
  }    

  n = getline(&buff,&len,fd);
  fclose(fd);
  
  ch = strtok(buff, " ");
  *upCapacity_kbps = atoi(ch);
  while (ch != NULL) {
    // printf("%s\n", ch); //TEST
    ch = strtok(NULL, " ");
    if(ch != NULL) *downCapacity_kbps = atoi(ch);
  }
  
  // printf("u[%d] - d[%d] \n",*upCapacity_kbps, *downCapacity_kbps); //TEST
  
  return 0;
}

/**
  Permite cargar los valores del fichero de inicializaci�n

*/

static int handler(void* user, const char* section, const char* name, const char* value)
{
    configuration* pconfig = (configuration*)user;

    #define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
    if (MATCH("files", "pathIN")) {
        pconfig->pathIN = strdup(value);
    } else if (MATCH("files", "inputs")) {
        pconfig->inputs = strdup(value);
    } else if (MATCH("files", "output")) {
        pconfig->output = strdup(value);
    } else if (MATCH("files", "capFile")) {
        pconfig->capFile = strdup(value);
    } else {
        return 0;  /* seccion/nombre desconocidos, error */
    }
    return 1;
}
