/* 
 * h264bitstream - a library for reading and writing H.264 video
 * Copyright (C) 2005-2007 Auroras Entertainment, LLC
 * Copyright (C) 2008-2011 Avail-TVN
 * 
 * Written by Alex Izvorski <aizvorski@gmail.com> and Alex Giladi <alex.giladi@gmail.com>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**
@author   Alex Izvorski <aizvorski@gmail.com> 
@author   Alex Giladi <alex.giladi@gmail.com>
@file     h264_sei.c
@brief    a library for reading and writing H.264 video
*/ 
 
#include "bs.h"
#include "h264_stream.h"
#include "h264_sei.h"

#include <stdio.h>
#include <stdlib.h> // malloc
#include <string.h> // memset

sei_t* sei_new()
{
    /* testPASS(); //TEST */    
    sei_t* s = (sei_t*)malloc(sizeof(sei_t));
    memset(s, 0, sizeof(sei_t));
    s->payload = NULL;
    /* testPASS(); //TEST */
    return s;
}

void sei_free(sei_t* s)
{
    if ( s->payload != NULL ) free(s->payload);
    free(s);
}

void read_sei_end_bits(h264_stream_t* h, bs_t* b )
{
    // if the message doesn't end at a byte border
    if ( !bs_byte_aligned( b ) )
    {
        if ( !bs_read_u1( b ) ) fprintf(stderr, "WARNING: bit_equal_to_one is 0!!!!\n");
        while ( ! bs_byte_aligned( b ) )
        {
            if ( bs_read_u1( b ) ) fprintf(stderr, "WARNING: bit_equal_to_zero is 1!!!!\n");
        }
    }

    read_rbsp_trailing_bits(h, b);
}

// D.1 SEI payload syntax
void read_sei_payload(h264_stream_t* h, bs_t* b, int payloadType, int payloadSize)
{
    sei_t* s = h->sei;

    s->payload = (uint8_t*)malloc(payloadSize);

    int i;

    for ( i = 0; i < payloadSize; i++ )
        s->payload[i] = bs_read_u(b, 8);
        
    read_sei_end_bits(h, b);
}

//G.13.1.1Scalability information SEI message syntax
void read_scalability_info(h264_stream_t* h){
  sei_t* s = h->sei;
  bs_t* b = bs_new(s->payload, s->payloadSize);
  s->svc_info.temporal_id_nesting_flag = bs_read_u1(b);
  s->svc_info.priority_layer_info_present_flag = bs_read_u1(b);
  s->svc_info.priority_id_setting_flag = bs_read_u1(b);
  s->svc_info.num_layers_minus1 = bs_read_ue(b);
  for(int i=0;i<s->svc_info.num_layers_minus1;i++){
    s->svc_info.layer_id[i] = bs_read_ue(b);
    s->svc_info.priority_id[i] = bs_read_u(b,6);
    s->svc_info.discardable_flag[i] = bs_read_u1(b);
    s->svc_info.dependency_id[i] = bs_read_u(b,3);
    s->svc_info.quality_id[i] = bs_read_u(b,4);
    s->svc_info.temporal_id[i] = bs_read_u(b,3);
    s->svc_info.sub_pic_layer_flag[i] = bs_read_u1(b);
    s->svc_info.sub_region_layer_flag[i] = bs_read_u1(b);
    s->svc_info.iroi_division_info_present_flag[i] = bs_read_u1(b);
    s->svc_info.profile_level_info_present_flag[i] = bs_read_u1(b);
    s->svc_info.bitrate_info_present_flag[i] = bs_read_u1(b);
    s->svc_info.frm_rate_info_present_flag[i] = bs_read_u1(b);
    s->svc_info.frm_size_info_present_flag[i] = bs_read_u1(b);
    s->svc_info.layer_dependency_info_present_flag[i] = bs_read_u1(b);
    s->svc_info.parameter_sets_info_present_flag[i] = bs_read_u1(b);
    s->svc_info.bitstream_restriction_info_present_flag[i] = bs_read_u1(b);
    s->svc_info.exact_inter_layer_pred_flag[i] = bs_read_u1(b);
    if(s->svc_info.sub_pic_layer_flag[i] || s->svc_info.iroi_division_info_present_flag[i])
      s->svc_info.exact_sample_value_match_flag[i] = bs_read_u1(b);
    s->svc_info.layer_conversion_flag[i] = bs_read_u1(b);
    s->svc_info.layer_output_flag[i] = bs_read_u1(b);
    if(s->svc_info.profile_level_info_present_flag[i])
      s->svc_info.layer_profile_level_idc[i] = bs_read_u(b,24);
    if(s->svc_info.bitrate_info_present_flag[i]){
      s->svc_info.avg_bitrate[i] = bs_read_u(b,16);
      s->svc_info.max_bitrate_layer[i] = bs_read_u(b,16);
      s->svc_info.max_bitrate_layer_representation[i] = bs_read_u(b,16);
      s->svc_info.max_bitrate_calc_window[i] = bs_read_u(b,16);
    }
    if(s->svc_info.frm_rate_info_present_flag[i]){
      s->svc_info.constant_frm_rate_idc[i] = bs_read_u(b,2);
      s->svc_info.avg_frm_rate[i] = bs_read_u(b,16);
    }
    if(s->svc_info.frm_size_info_present_flag[i] || s->svc_info.iroi_division_info_present_flag[i]){
      s->svc_info.frm_width_in_mbs_minus1[i] = bs_read_ue(b);
      s->svc_info.frm_height_in_mbs_minus1[i] = bs_read_ue(b);
    }
    if(s->svc_info.sub_region_layer_flag[i]){
      s->svc_info.base_region_layer_id[i] = bs_read_ue(b);
      s->svc_info.dynamic_rect_flag[i] = bs_read_u1(b);
      if(s->svc_info.dynamic_rect_flag[i]){
        s->svc_info.horizontal_offset[i] = bs_read_u(b,16);
        s->svc_info.vertical_offset[i] = bs_read_u(b,16);
        s->svc_info.region_width[i] = bs_read_u(b,16);
        s->svc_info.region_height[i] = bs_read_u(b,16);
      }
    }
    if(s->svc_info.sub_pic_layer_flag[i])
      s->svc_info.roi_id[i] = bs_read_ue(b);
    if(s->svc_info.iroi_division_info_present_flag[i]){
      s->svc_info.iroi_grid_flag[i] = bs_read_u1(b);
      if(s->svc_info.iroi_grid_flag[i]){
        s->svc_info.grid_width_in_mbs_minus1[i] = bs_read_ue(b);
        s->svc_info.grid_height_in_mbs_minus1[i] = bs_read_ue(b);
      }else{
        s->svc_info.num_rois_minus1[i] = bs_read_ue(b);
        for(int j=0;j<=s->svc_info.num_rois_minus1[i];j++){
          s->svc_info.first_mb_in_roi[i][j] = bs_read_ue(b);
          s->svc_info.roi_width_in_mbs_minus1[i][j] = bs_read_ue(b);
          s->svc_info.roi_height_in_mbs_minus1[i][j] = bs_read_ue(b);
        }
      }
    }
    if(s->svc_info.layer_dependency_info_present_flag[i]){
      s->svc_info.num_directly_dependent_layers[i] = bs_read_ue(b);
      for(int j=0;j<s->svc_info.num_directly_dependent_layers[i];j++)
        s->svc_info.directly_dependent_layer_id_delta_minus1[i][j] = bs_read_ue(b);
    }else
      s->svc_info.layer_dependency_info_src_layer_id_delta[i] = bs_read_ue(b);
    if(s->svc_info.parameter_sets_info_present_flag[i]){
      s->svc_info.num_seq_parameter_sets[i] = bs_read_ue(b);
      for(int j=0;j<s->svc_info.num_seq_parameter_sets[i];j++)
        s->svc_info.seq_parameter_set_id_delta[i][j] = bs_read_ue(b);
      s->svc_info.num_subset_seq_parameter_sets[i] = bs_read_ue(b);
      for(int j=0;j<s->svc_info.num_subset_seq_parameter_sets[i];j++)
        s->svc_info.subset_seq_parameter_set_id_delta[i][j] = bs_read_ue(b);
      s->svc_info.num_pic_parameter_sets_minus1[i] = bs_read_ue(b);
      for(int j=0;j<s->svc_info.num_pic_parameter_sets_minus1[i];j++)
        s->svc_info.pic_parameter_set_id_delta[i][j] = bs_read_ue(b);
    }else
      s->svc_info.parameter_sets_info_src_layer_id_delta[i] = bs_read_ue(b);
    if(s->svc_info.bitstream_restriction_info_present_flag[i]){
      s->svc_info.motion_vectors_over_pic_boundaries_flag[i] = bs_read_u1(b);
      s->svc_info.max_bytes_per_pic_denom[i] = bs_read_ue(b);
      s->svc_info.max_bits_per_mb_denom[i] = bs_read_ue(b);
      s->svc_info.log2_max_mv_length_horizontal[i] = bs_read_ue(b);
      s->svc_info.log2_max_mv_length_vertical[i] = bs_read_ue(b);
      s->svc_info.max_num_reorder_frames[i] = bs_read_ue(b);
      s->svc_info.max_dec_frame_buffering[i] = bs_read_ue(b);
    }
    if(s->svc_info.layer_conversion_flag[i]){
      s->svc_info.conversion_type_idc[i] = bs_read_ue(b);
      for(int j=0;j<2;j++){
        s->svc_info.rewriting_info_flag[i][j] = bs_read_u1(b);
        if(s->svc_info.rewriting_info_flag[i][j]){
          s->svc_info.rewriting_profile_level_idc[i][j] = bs_read_u(b,24);
          s->svc_info.rewriting_avg_bitrate[i][j] = bs_read_u(b,16);
          s->svc_info.rewriting_max_bitrate[i][j] = bs_read_u(b,16);
        }
      }
    }
  }
  if(s->svc_info.priority_id_setting_flag){
    s->svc_info.pr_num_dIds_minus1 = bs_read_ue(b);
    for(int i=0;i<s->svc_info.pr_num_dIds_minus1;i++){
      s->svc_info.pr_dependency_id[i] = bs_read_u(b,3);
      s->svc_info.pr_num_minus1[i] = bs_read_ue(b);
      for(int j=0;i<s->svc_info.pr_num_minus1[i];i++){
        s->svc_info.pr_id[i][j] = bs_read_ue(b);
        s->svc_info.pr_profile_level_idc[i][j] = bs_read_u(b,24);
        s->svc_info.pr_avg_bitrate[i][j] = bs_read_u(b,16);
        s->svc_info.pr_max_bitrate[i][j] = bs_read_u(b,16);
      }
    }
  }
  if(s->svc_info.priority_id_setting_flag){
    int PriorityIdSettingUriIdx = 0;
    do
      s->svc_info.priority_id_setting_uri[PriorityIdSettingUriIdx] = bs_read_u8(b);
    while(s->svc_info.priority_id_setting_uri[PriorityIdSettingUriIdx++]!=0);
  }
}

// D.1 SEI payload syntax
void write_sei_payload(h264_stream_t* h, bs_t* b, int payloadType, int payloadSize)
{
    sei_t* s = h->sei;

    int i;
    for ( i = 0; i < s->payloadSize; i++ )
        bs_write_u(b, 8, s->payload[i]);
}



