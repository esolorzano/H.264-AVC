/* 
 * h264bitstream - a library for reading and writing H.264 video
 * Copyright (C) 2005-2007 Auroras Entertainment, LLC
 * Copyright (C) 2008-2011 Avail-TVN
 * 
 * Written by Alex Izvorski <aizvorski@gmail.com> and Alex Giladi <alex.giladi@gmail.com>
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**
@author   Alex Izvorski <aizvorski@gmail.com> 
@author   Alex Giladi <alex.giladi@gmail.com>
@file     h264_sei.h
@brief    a library for reading and writing H.264 video
*/
 
#include <stdint.h>

#ifndef _H264_SEI_H
#define _H264_SEI_H        1

#include <stdint.h>

#include "bs.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
    int payloadType;
    int payloadSize;
    uint8_t* payload;
    
    struct
    {
      int temporal_id_nesting_flag;
      int priority_layer_info_present_flag;
      int priority_id_setting_flag;
      int num_layers_minus1;
        int layer_id[100]; 
        int priority_id[100];
        int discardable_flag[100];
        int dependency_id[100];
        int quality_id[100];
        int temporal_id[100];
        int sub_pic_layer_flag[100];
        int sub_region_layer_flag[100];
        int iroi_division_info_present_flag[100];
        int profile_level_info_present_flag[100];
        int bitrate_info_present_flag[100];
        int frm_rate_info_present_flag[100];
        int frm_size_info_present_flag[100];
        int layer_dependency_info_present_flag[100];
        int parameter_sets_info_present_flag[100];
        int bitstream_restriction_info_present_flag[100];
        int exact_inter_layer_pred_flag[100];      
        int exact_sample_value_match_flag[100]; 
        int layer_conversion_flag[100]; 
        int layer_output_flag[100]; 
        int layer_profile_level_idc[100]; 
        int avg_bitrate[100]; 
        int max_bitrate_layer[100]; 
        int max_bitrate_layer_representation[100]; 
        int max_bitrate_calc_window[100]; 
        int constant_frm_rate_idc[100]; 
        int avg_frm_rate[100]; 
        int frm_width_in_mbs_minus1[100]; 
        int frm_height_in_mbs_minus1[100]; 
        int base_region_layer_id[100]; 
        int dynamic_rect_flag[100]; 
        int horizontal_offset[100]; 
        int vertical_offset[100]; 
        int region_width[100]; 
        int region_height[100]; 
        int roi_id[100]; 
        int iroi_grid_flag[100]; 
        int grid_width_in_mbs_minus1[100]; 
        int grid_height_in_mbs_minus1[100]; 
        int num_rois_minus1[100]; 
        int first_mb_in_roi[100][100]; 
        int roi_width_in_mbs_minus1[100][100]; 
        int roi_height_in_mbs_minus1[100][100]; 
        int num_directly_dependent_layers[100]; 
        int directly_dependent_layer_id_delta_minus1[100][100]; 
        int layer_dependency_info_src_layer_id_delta[100]; 
        int num_seq_parameter_sets[100]; 
        int seq_parameter_set_id_delta[100][100]; 
        int num_subset_seq_parameter_sets[100]; 
        int subset_seq_parameter_set_id_delta[100][100]; 
        int num_pic_parameter_sets_minus1[100]; 
        int pic_parameter_set_id_delta[100][100]; 
        int parameter_sets_info_src_layer_id_delta[100]; 
        int motion_vectors_over_pic_boundaries_flag[100]; 
        int max_bytes_per_pic_denom[100]; 
        int max_bits_per_mb_denom[100]; 
        int log2_max_mv_length_horizontal[100]; 
        int log2_max_mv_length_vertical[100]; 
        int max_num_reorder_frames[100]; 
        int max_dec_frame_buffering[100]; 
        int conversion_type_idc[100]; 
        int rewriting_info_flag[100][100]; 
        int rewriting_profile_level_idc[100][100]; 
        int rewriting_avg_bitrate[100][100]; 
        int rewriting_max_bitrate[100][100]; 
      int pr_num_dIds_minus1;
        int pr_dependency_id[100]; 
        int pr_num_minus1[100]; 
        int pr_id[100][100]; 
        int pr_profile_level_idc[100][100]; 
        int pr_avg_bitrate[100][100]; 
        int pr_max_bitrate[100][100]; 
      int priority_id_setting_uri[100]; 
    } svc_info;
} sei_t;

sei_t* sei_new();
void sei_free(sei_t* s);

//D.1 SEI payload syntax
#define SEI_TYPE_BUFFERING_PERIOD 0
#define SEI_TYPE_PIC_TIMING       1
#define SEI_TYPE_PAN_SCAN_RECT    2
#define SEI_TYPE_FILLER_PAYLOAD   3
#define SEI_TYPE_USER_DATA_REGISTERED_ITU_T_T35  4
#define SEI_TYPE_USER_DATA_UNREGISTERED  5
#define SEI_TYPE_RECOVERY_POINT   6
#define SEI_TYPE_DEC_REF_PIC_MARKING_REPETITION 7
#define SEI_TYPE_SPARE_PIC        8
#define SEI_TYPE_SCENE_INFO       9
#define SEI_TYPE_SUB_SEQ_INFO    10
#define SEI_TYPE_SUB_SEQ_LAYER_CHARACTERISTICS  11
#define SEI_TYPE_SUB_SEQ_CHARACTERISTICS  12
#define SEI_TYPE_FULL_FRAME_FREEZE  13
#define SEI_TYPE_FULL_FRAME_FREEZE_RELEASE  14
#define SEI_TYPE_FULL_FRAME_SNAPSHOT  15
#define SEI_TYPE_PROGRESSIVE_REFINEMENT_SEGMENT_START  16
#define SEI_TYPE_PROGRESSIVE_REFINEMENT_SEGMENT_END  17
#define SEI_TYPE_MOTION_CONSTRAINED_SLICE_GROUP_SET  18
#define SEI_TYPE_FILM_GRAIN_CHARACTERISTICS  19
#define SEI_TYPE_DEBLOCKING_FILTER_DISPLAY_PREFERENCE  20
#define SEI_TYPE_STEREO_VIDEO_INFO  21
#define SEI_TYPE_POST_FILTER_HINT	22
#define SEI_TYPE_TONE_MAPPING_INFO	23
#define SEI_TYPE_SCALABILITY_INFO	24
#define SEI_TYPE_SUB_PIC_SCALABLE_LAYER	25
#define SEI_TYPE_NON_REQUIRED_LAYER_REP	26
#define SEI_TYPE_PRIORITY_LAYER_INFO	27
#define SEI_TYPE_LAYERS_NOT_PRESENT	28
#define SEI_TYPE_LAYER_DEPENDENCY_CHANGE	29
#define SEI_TYPE_SCALABLE_NESTING	30
#define SEI_TYPE_BASE_LAYER_TEMPORAL_HRD	31
#define SEI_TYPE_QUALITY_LAYER_INTEGRITY_CHECK	32
#define SEI_TYPE_REDUNDANT_PIC_PROPERTY	33
#define SEI_TYPE_TL0_DEP_REP_INDEX	34
#define SEI_TYPE_TL_SWITCHING_POINT	35
#define SEI_TYPE_PARALLEL_DECODING_INFO	36
#define SEI_TYPE_MVC_SCALABLE_NESTING	37
#define SEI_TYPE_VIEW_SCALABILITY_INFO	38
#define SEI_TYPE_MULTIVIEW_SCENE_INFO	39
#define SEI_TYPE_MULTIVIEW_ACQUISITION_INFO	40
#define SEI_TYPE_NON_REQUIRED_VIEW_COMPONENT	41
#define SEI_TYPE_VIEW_DEPENDENCY_CHANGE	42
#define SEI_TYPE_OPERATION_POINTS_NOT_PRESENT	43
#define SEI_TYPE_BASE_VIEW_TEMPORAL_HRD	44
#define SEI_TYPE_FRAME_PACKING_ARRANGEMENT	45
#define SEI_TYPE_MULTIVIEW_VIEW_POSITION	46
#define SEI_TYPE_DISPLAY_ORIENTATION	47
#define SEI_TYPE_MVCD_SCALABLE_NESTING	48
#define SEI_TYPE_MVCD_VIEW_SCALABILITY_INFO	49
#define SEI_TYPE_DEPTH_REPRESENTATION_INFO	50
#define SEI_TYPE_THREE_DIMENSIONAL_REFERENCE_DISPLAYS_INFO	51
#define SEI_TYPE_DEPTH_TIMING	52
#define SEI_TYPE_DEPTH_SAMPLING_INFO	53

#define testPASS()  printf("%d @ %s - %s()......\n",__LINE__,__FILE__,__FUNCTION__)

#ifdef __cplusplus
}
#endif

#endif
