var searchData=
[
  ['bs_5ft',['bs_t',['../structbs__t.html',1,'']]]
];
