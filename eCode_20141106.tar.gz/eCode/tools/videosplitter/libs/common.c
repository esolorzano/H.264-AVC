#include "common.h"

/**
 *  @brief Calcula el tiempo transcurrido en un periodo
 *  
 *  @param [out] result diferencia de tiempo
 *  @param [in] t2 instante final
 *  @param [in] t1 instante inicial
 *  @return 0: diferencia positiva, 1: diferencia negativa
 */
int timeval_subtract(struct timeval *result, struct timeval *t2, struct timeval *t1)
{
    long int diff = (t2->tv_usec + 1000000 * t2->tv_sec) - (t1->tv_usec + 1000000 * t1->tv_sec);
    result->tv_sec = diff / 1000000;
    result->tv_usec = diff % 1000000;

    return (diff<0);
}

/**
 *  @brief Calcula el bitrate en bits-per-second (bps)
 *  
 *  @param [in] diff ventana de tiempo empleado para enviar datos
 *  @param [in] sizeData tamaño de los datos enviados
 *  @return bitrate en bps
 */
float calculateRate(int sizeData, struct timeval diff){
  return 8*sizeData/((float)diff.tv_sec + (float)diff.tv_usec/1000000);
}

/**
 *  @brief Calcula la duracio de un periodo. 
 *  
 *  @param [in, out] times estructura donde se almacenan los valores de tiempo
 *  @param [in] option opcion a realizar. 1: set begin time, 2: set end time.
 */
void getPeriodTime(times_t *times, char option){
  struct timeval* tvBegin = &(times->tvBegin);
  struct timeval* tvEnd = &(times->tvEnd);
  struct timeval* tvDiff = &(times->tvDiff);
  
  switch(option){
    case 'i':
      break;
    case 'b': /* begin */
      gettimeofday(tvBegin, NULL);
      break;
    case 'e': /* end */
      gettimeofday(tvEnd, NULL);
      timeval_subtract(tvDiff, tvEnd, tvBegin);
      break;
  }
}

/**
	@brief			genera una espera de 31.25ms
*/
void doSleep(){
	struct timespec ts;
	ts.tv_sec=0;
	ts.tv_nsec=31250000; //0.03125s
	nanosleep(&ts,&ts);
}

float timeSecs(struct timeval diff){
	return (float)diff.tv_sec + (float)diff.tv_usec/1000000;
}
