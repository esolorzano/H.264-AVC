#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> /*nanosleep()*/
#include <limits.h> /*PIPE_BUF is defined here.*/

/*socket TCP*/
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

/*throughput calc*/
#include <sys/time.h>

#define LOCALBUFFER_SIZE 1*1024*1024
#define EOS 'E'
#define EOS_MSG "E"
#define CONTROLLER_BLOCKUNIT 32*1024
#define CONTROLLER_BLOCKS 16
#define SELECTOR_BLOCKSIZE CONTROLLER_BLOCKS*CONTROLLER_BLOCKUNIT

typedef struct{
  struct timeval tvBegin;
  struct timeval tvEnd;
  struct timeval tvDiff;
} times_t;

int timeval_subtract(struct timeval *result, struct timeval *t2, struct timeval *t1);
float calculateRate(int sizeData, struct timeval diff);
void getPeriodTime(times_t *times, char option);
void doSleep();
float timeSecs(struct timeval diff);
