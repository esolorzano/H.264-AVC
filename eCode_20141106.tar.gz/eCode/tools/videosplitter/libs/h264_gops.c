/**
 *  @author Edwin Solorzano <solorzano.em@gmail.com>
 *  @file h264_gops.c
 *  @date 2013-10-23
 *  @version 0.1.0
 *  @brief conjunto de funciones para gestionar los GOPs de un stream H264
 */
 
#include "h264_gops.h"

/**
 *  @brief Obtiene un GOP especifico del stream.
 *  
 *  @param [in,out] srs estado del stream leido
 *  @param [out] GOPbuffer buffer que contendrá las NALunits del GOP
 *  @param [in] index GOP requerido del stream que se esté leyendo
 *  @return longitud del GOP. Si el valor de index es menor al contador de GOPs se retornará la diferencia (valor negativo)
 */
int getGOP(stream_read_status_t* srs, uint8_t* GOPbuffer, int index){
	int n;
	int GOPincompleto = 1;
	int offset = 0;
	uint8_t separador[10] = {0};
	
	//copiado de la cabecera del GOP (a partir del segundo GOP)
	if(srs->nextGOPHeaderSize){
		memcpy(GOPbuffer,srs->nextGOPHeaderBuffer,srs->nextGOPHeaderSize);
		offset += srs->nextGOPHeaderSize;
		srs->nextGOPHeaderSize = 0;
	}
	
	do{
		//leer NAL units
		n = read_nal(srs);
		if(n == 0) return 0;
		int nal_size = srs->nal_end - srs->nal_start;
// 		debug_bytes(srs->p_dump,((nal_size<8)?nal_size:8)); //TEST
		h264_stream_t* h = srs->h;
		int nal_type = h->nal->nal_unit_type;
		
		//detección y almacenamiento de la cabecera del siguiente GOP
		if(nal_type == NAL_UNIT_TYPE_AUD){
      if(srs->GOPcounter){ //Guardar cabecera para el siguiente GOP
				GOPincompleto = 0;
				uint8_t separadorNAL[4] = {0,0,0,1};
				srs->nextGOPHeaderSize = 4 + nal_size;
				memcpy(srs->nextGOPHeaderBuffer,separadorNAL,4);
				memcpy(srs->nextGOPHeaderBuffer + 4,srs->p_dump,nal_size);
				bzero(srs->p_dump,nal_size);
			}else{ //Guardar cabecera en buffer de salida del primer GOP
				//identificar el tipo de separador y copiado en buffer de salida
				int separador_size = srs->nal_start;
				bzero(separador,10); separador[separador_size-1] = 1;
				memcpy(GOPbuffer + offset,separador,separador_size);
				offset += separador_size;
				memcpy(GOPbuffer + offset,srs->p_dump,nal_size);
				bzero(srs->p_dump,nal_size);
				offset += nal_size;
				srs->GOPcounter++;
			}
		}else{ //copiar NAL unit al buffer de salida
			//identificar el tipo de separador y copiado en buffer de salida
			int separador_size = srs->nal_start;
			bzero(separador,10); separador[separador_size-1] = 1;
			memcpy(GOPbuffer + offset,separador,separador_size);
			offset += separador_size;
			memcpy(GOPbuffer + offset,srs->p_dump,nal_size);
			bzero(srs->p_dump,nal_size);
			offset += nal_size;
		}
	}while(GOPincompleto);
	
	return offset;
}

/**
 *  @brief Reservar e inicializar los espacio de memoria para cada input stream
 *  
 *  @param [out] estado del stream
 *  
 */
void init_stream_read_status(stream_read_status_t* srs){

  srs->buf = (uint8_t*)malloc( BUFSIZE );
  srs->p = srs->buf;
  srs->p_dump = srs->buf;
  srs->h = h264_new();
  srs->rsz = 0;
  srs->sz = 0;
  srs->off = 0;
  srs->first_load = 1;
  srs->nu_index = 0;

  srs->p_slice_I_data = (uint8_t*)malloc( 1*1024*1024 );
  srs->p_slice_I_size = 0;

  srs->GOPcounter = 0;
  srs->nextGOPHeaderBuffer = (uint8_t*)malloc( SIZE_GOPBUFFER );
  srs->nextGOPHeaderSize = 0;
  srs->meanGOPsize = 0;
}

/**
 *  @brief Liberar memoria utilizada por el estado de los streams
 *  
 *  @param [in] stream_read_vars Parameter_Description
 */
void free_stream_read_status(stream_read_status_t* srs){
  free(srs->buf);
  h264_free(srs->h);
}


/**
 *  @brief Lectura de una NAL unit de uno de los input streams
 *  
 *  @param [in,out] srs estado de los streams leidos.
 *  @return 0 si se llegó al final del stream, caso contrario el numero de bytes leidos.
 *  
 */
int read_nal(stream_read_status_t* srs)
{
  /* testPASS(); //TEST */
  uint8_t* buf = srs->buf;
  uint8_t** p = &srs->p;
  uint8_t** p_dump = &srs->p_dump;
  int* nal_start = &srs->nal_start;
  int* nal_end = &srs->nal_end;
  size_t* rsz = &srs->rsz;
  size_t* sz = &srs->sz;
  int64_t* off = &srs->off;    
  h264_stream_t* h = srs->h;
  FILE* fsin = srs->fs;
  int* first_load = &srs->first_load;
  
  //printf("%d @ %s : %s() - fsin: %p\n",__LINE__,__FILE__,__FUNCTION__,fsin); //TEST
  /* testPASS(); //TEST */

  if(*first_load){
    *rsz = fread(buf + *sz, 1, BUFSIZE - *sz, fsin);
    *first_load = 0;
    *sz += *rsz;
  }

  //printf("%d @ %s : %s() - rsz: %d\n",__LINE__,__FILE__,__FUNCTION__,*rsz); //TEST
  /* testPASS(); //TEST */
  
  if (*rsz == 0)
  {
    if (ferror(fsin)) { fprintf( stderr, "!! Error: read failed: %s \n", strerror(errno)); /*return *rsz;*/ }
    return *rsz;  // if (feof(fsin)) 
  }
  
  int is_there_nal = find_nal_unit(*p, *sz, nal_start, nal_end);
  //printf("%d @ %s : %s() - is_there_nal: %d\n",__LINE__,__FILE__,__FUNCTION__,is_there_nal); //TEST
  /* testPASS(); //TEST */
  if ( is_there_nal > 0)
  {
      srs->nu_index++;   
      
      *p += *nal_start;
      //printf("%d @ %s : %s() - nal size: %d\n",__LINE__,__FILE__,__FUNCTION__,*nal_end - *nal_start); //TEST
      //printf("%d @ %s : %s() - base: %p p: %p - diff(%d)\n",__LINE__,__FILE__,__FUNCTION__,buf + *sz,*p, buf + *sz - *p); //TEST
      read_nal_unit(h, *p, *nal_end - *nal_start);
      /* testPASS(); //TEST */
      // debug_bytes(*p,*nal_end - *nal_start); //TEST
      // printf(". . . . . . . . . . . . . . . .\n"); //TEST
      *p_dump = *p;
      *p += (*nal_end - *nal_start);
      *sz -= *nal_end;
      
  }else{

    // printf("*");//TEST
    
    memmove(buf, *p, *sz);
    /* testPASS(); //TEST */
    *off += *p - buf;
    *p = buf;    
    
    *rsz = fread(buf + *sz, 1, BUFSIZE - *sz, fsin); 
    /* testPASS(); //TEST */
    *sz += *rsz;
    
    return *rsz;
  }

  /* testPASS(); //TEST */
  
  // if no NALs found in buffer, discard it
  if (*p == buf) 
  {
      fprintf( stderr, "!! Did not find any NALs between offset %ld (0x%04lX), size %ld (0x%04lX), discarding \n",
             (long int)*off, 
             (long int)*off, 
             (long int)*off + *sz, 
             (long int)*off + *sz);

      *p = buf + *sz;
      *sz = 0;
  }
  
  return *rsz;
}

/**
 *  @brief reinicia todos las regiones de memoria utilizados así como las variables de estado del stream
 *  
 *  @param [in,out] srs estado del stream
 */
void reset_stream_read_status(stream_read_status_t* srs){
  FILE* fs = srs->fs;  
  
  free_stream_read_status(srs);
  init_stream_read_status(srs);
  rewind(fs);
  srs->fs = fs;
}

/**
 *  @brief Calcula la longitud media de los GOPs de un stream
 *  
 *  @param [in] stream_read_status estado del stream
 *  @param [in] GOPsize longitud de un GOP
 */
void calculateMeanGOPsize(stream_read_status_t* srs,int GOPsize){
  srs->meanGOPsize = (srs->meanGOPsize*srs->GOPcounter + GOPsize)/srs->GOPcounter;
}
