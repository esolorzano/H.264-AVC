/**
 *  @author Edwin Solorzano <solorzano.em@gmail.com>
 *  @file h264_gops.h
 *  @date 2013-10-23
 *  @version X.Y.Z
 *  @brief conjunto de funciones para gestionar los GOPs de un stream H264
 */

#ifndef _H264_GOPS_H
#define _H264_GOPS_H  1 
 
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include "../../h264bitstream-0.1.10/bs.h"
#include "../../h264bitstream-0.1.10/h264_stream.h" 
 
#define BUFSIZE 256*1024*1024 //128MB
//#define BUFSIZE 8*1024*1024 //128MB
#define SIZE_GOPBUFFER 1024*1024 /*aumentar si aparece el error:  malloc(): memory corruption: 0x0827d5b0 *** */
#define SEPARATOR4_SIZE 4
#define SEPARATOR3_SIZE 3
#define SEPARATORHEADER_SIZE 4

//#define testPASS()  printf("%d @ %s - %s()...\n",__LINE__,__FILE__,__FUNCTION__)

typedef struct
{
  /*@{*/
  FILE* fs;                     /**<Descriptor del fichero que contiene el stream H.264 */
  
  uint8_t* buf;                 /**<Buffer a donde se copiará el stream H.264 */
  uint8_t* p;                   /**<Puntero que recorre *buf, buffer que contiene el stream H.264 */
  uint8_t* p_dump;              /**<Puntero que apunta al inicio de los datos de una unidad NAL */
  int nal_start;                /**<Ubicación del primer byte del la unidad NAL tomando como referencia *p */
  int nal_end;                  /**<Ubicación del último byte del la unidad NAL tomando como referencia *p  */
  size_t rsz;                   /**<Numero de bytes explorados de *buf */
  size_t sz;                    /**<Longitud de *buf */
  int64_t off;                  
    
  h264_stream_t* h;             /**<Puntero a la esctructura que contiene los valores de los campos de una unidad NAL */
  
  int first_load;               /**<Bandera que indica la primera carga de *buf */
  int nu_index;                 /**<Número de unidades NAL leidas */
  
  uint8_t* p_slice_I_data;      
  int p_slice_I_size;           
  
  int GOPcounter;               /**<Número de GOPs leidos */
  uint8_t* nextGOPHeaderBuffer; /**<Datos de la cabecera del siguiente GOP */
  int nextGOPHeaderSize;        /**<Longitud de la cabecera del siguiente GOP */
  int meanGOPsize;              /**<Longitud media de un GOP */
  /*@}*/
  
} stream_read_status_t;

int getGOP(stream_read_status_t* srs, uint8_t* GOPbuffer, int index);
void init_stream_read_status(stream_read_status_t* stream_read_status);
void free_stream_read_status(stream_read_status_t* stream_read_status);
int read_nal(stream_read_status_t* stream_read_status);
void reset_stream_read_status(stream_read_status_t* stream_read_status);
void calculateMeanGOPsize(stream_read_status_t* stream_read_status,int GOPsize);

#endif
