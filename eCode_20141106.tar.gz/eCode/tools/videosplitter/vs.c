/**
 *  @author Edwin Solorzano <solorzano.em@gmail.com>
 *  @file vs.c
 *  @date 2014-07-04
 *  @version 0.1.0
 *  @brief 
 *  Herramienta que permite dividir un stream H.264 a nivel GOP para crear\n
 *  ficheros que contengan todos los GOPs para reproducir multiplos de un\n 
 *  segundo de video.
 */
 
#include "vs.h"

/*----------------------------------------------------------------------------*/

/**
 *  @brief Programa principal
 */
int main(){

	//fclose(fopen("salida_local.264","w+")); //TEST

  //== Carga de configuracion ==
	config_vs_t config;
  if (ini_parse("config.ini", handler, &config) < 0) {
    printf("No se pudo cargar la configuration de 'config.ini'\n");
    return 1;
  }

  if(config.debug){
		char * cwd; cwd = getcwd (0, 0);
    printf("config params:\n");
    printf("\tConfig file: %s/%s\n",cwd,config.inFile);
    printf("\tsource     : %s\n",config.sourceH264);
    printf("\tout path   : %s\n",config.outpath);
    printf("\tfile prefix: %s\n",config.fileprefix);
    printf("\tdebug: %d\n\n",config.debug);
  }

  //bitrate file info
  char csvfile[100] = {0};
	strcpy(csvfile,config.outpath);
	strcat(csvfile,config.fileprefix);
	strcat(csvfile,"bitrate.csv\0");
	fclose(fopen(csvfile,"w+"));
  
	//buffers setup
	uint8_t* GOPbuffer = (uint8_t*)calloc(GOPBUFFER_SIZE,sizeof(uint8_t));
	uint8_t* streamSegment = (uint8_t*)calloc(STREAMSEG_SIZE,sizeof(uint8_t));
	int iGOPCounter = 1;
	stream_read_status_t sources_status;
	if(setup(&sources_status, config)) return 1;

	int n = 0;
	int gz = 0;
	int leido = 0;
	int last_cnt = 0;
	char qlevel = 0;
	int fileCounter = 1;
	do{

		//lectura de GOPs
		bzero(GOPbuffer,GOPBUFFER_SIZE);
		gz = getGOP(&sources_status, GOPbuffer, iGOPCounter++);
		//testSaveLocal(GOPbuffer,gz); //TEST
		
		//GOP a buffer
		memcpy(streamSegment + leido,GOPbuffer,gz);

		//envio datos buffer al siguiente proceso
		if(((iGOPCounter-1) % (GOPSinSECOND*config.nsegundos))==0){
			//printf("sz:%8d|g:%d\n",leido,(iGOPCounter-last_cnt)); //TEST

			//creando fichero de un segundo de video
			createH264file(leido + gz, streamSegment, fileCounter++, config);

			//reinicio contadores
			bzero(streamSegment,STREAMSEG_SIZE);
			leido = 0;
			last_cnt = iGOPCounter;
		}else{
			leido += gz;
		}
	}while(gz);

	//printf("sz:%8d|g:%d\n",leido,(iGOPCounter-last_cnt-1)); //TEST

	if(leido > 0){
		//creando fichero de un segundo de video
		createH264file(leido, streamSegment, fileCounter, config);
	}

	createMediaDescriptionFile(config,fileCounter);
	printf("Se crearon %d ficheros.\n",fileCounter);
	printf("Los ficheros creados se pueden encontrar en:\n  %s\n",config.outpath);
	printf("...................- DONE!! -...................\n\n");

	//freeing resources
	free_stream_read_status(&sources_status);
	free(GOPbuffer);
	free(streamSegment);

	return 0;
}

/*----------------------------------------------------------------------------*/

/**
 *  @brief Crea un fichero H.264 
 *  
 *  @param [in] size longitud del buffer que contiene los datos
 *  @param [in] buffer buffer que contiene el stream H.264
 *  @param [in] fileCounter numero de secuencia del fichero a crear
 *  @param [in] cf estructura de configuración
 */
void createH264file(int size, uint8_t* buffer, int fileCounter, config_vs_t cf){
	char filename[100] = {0};
	char* filenumber = itoa(fileCounter);
	strcpy(filename,cf.outpath);
	strcat(filename,cf.fileprefix);
	strcat(filename,filenumber);
	strcat(filename,".264\0");
	printf("creando fichero:%s\n",filename);//TEST
	recordBitrate(filename,size,cf);
	FILE* fd = fopen(filename,"wb+");
	fwrite(buffer,sizeof(uint8_t),size,fd);
	fclose(fd);
	
	
}

/**
 *  @brief Inicializa la aplicación. Inicializa las estructuras usadas para \n
 *  explorar el stream H-264
 *  
 *  @param [in] sources_status estructura para explorar el stream H.264
 *  @param [in] config estructura de configuración de la aplicación
 *  @return retorna 1 si se ha presentado un error y 0 si todo fue correcto.
 */
int setup(stream_read_status_t* sources_status, config_vs_t config){

	init_stream_read_status(sources_status);
	sources_status->meanGOPsize = MEANGOP_SIZE;
	sources_status->fs = fopen(config.sourceH264,"rb");

	return 0;
}

/**
 *  @brief Libera recursos de memoria y cierra ficheros relacionados con la \n
 *  exploración del stream H.264
 *  
 *  @param [in] sources_status estructura para explorar el stream H.264
 *  @return retorna 1 si se ha presentado un error y 0 si todo fue correcto.
 */
int setdown(stream_read_status_t* sources_status){
	fclose(sources_status->fs);
	free_stream_read_status(sources_status);
	return 0;
}

/**
 *  @brief Permite cargar los valores del fichero de inicialización
 *  
 */
static int handler(void* user, const char* section, const char* name, const char* value)
{
    config_vs_t* pconfig = (config_vs_t*)user;

    #define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0
    if (MATCH("files", "inFile")) {
        pconfig->inFile = strdup(value);
    } else if (MATCH("files", "sourceH264")) {
        pconfig->sourceH264 = strdup(value);
    } else if (MATCH("files", "outpath")) {
        pconfig->outpath = strdup(value);
    } else if (MATCH("files", "fileprefix")) {
        pconfig->fileprefix = strdup(value);
    } else if (MATCH("files", "nsegundos")) {
        pconfig->nsegundos = atoi(value);
    } else if (MATCH("files", "mediadesc")) {
        pconfig->mediadesc = strdup(value);
    } else if (MATCH("tracer", "debug")) {
        pconfig->debug = atoi(value);
    } else {
        return 0;  /* seccion/nombre desconocidos, error */
    }

    return 1;
}

char* itoa(int val){
  int base = 10;
	static char buf[32] = {0};	
	int i = 30;
	
	for(; val && i ; --i, val /= base)
	
		buf[i] = "0123456789abcdef"[val % base];
	
	return &buf[i+1];	
}

/**
 *  @brief Crea el fichero de descripción del contenido de la carpeta donde se \n
 *  guardan los ficheros segmento de un stream H.264
 *  
 *  @param [in] config Configuración de la aplicación. Contiene la ruta de la carpeta a describir
 *  @param [in] fileCounter Número total de ficheros segmento creados
 */
void createMediaDescriptionFile(config_vs_t config,int fileCounter){
	char filename[100] = {0};
	strcpy(filename,config.outpath);
	strcat(filename,config.mediadesc);

	if( access( filename, F_OK ) == -1 ) {
		FILE* fd = fopen(filename,"w+");
		fprintf(fd,";media description file\n");
		fprintf(fd,"[desc]\n");
		fprintf(fd,"path = %s\n",config.outpath);
		fprintf(fd,"extension = .264\n");
		fprintf(fd,"numfiles = %d\n",fileCounter);
		fprintf(fd,"prefixQL1 =  ; _QP40_ <---- prefijo fichero stream QP40\n");
		fprintf(fd,"prefixQL2 =  ; _QP30_ <---- prefijo fichero stream QP30\n");
		fprintf(fd,"prefixQL3 =  ; _QP20_ <---- prefijo fichero stream QP20\n");
		fprintf(fd,"prefixQL4 =  ; _QP10_ <---- prefijo fichero stream QP10\n");
		fclose(fd);
	}
}

void testSaveLocal(uint8_t* buffer, int size){
	FILE* fd = fopen("salida_local.264","a+");
	fwrite(buffer,1,size,fd);
	fclose(fd);
}

/**
 *  @brief Registra el bitrate necesario para transmitir cada fichero segmento H.264
 *  
 *  @param [in] filename Nombre del fichero segmento
 *  @param [in] size longitud del fichero segmento
 *  @param [in] cf esctuctura de configuración que contiene la duración del fichero segmento
 */
void recordBitrate(char* filename, int size, config_vs_t cf){
	char csvfile[100] = {0};
	strcpy(csvfile,cf.outpath);
	strcat(csvfile,cf.fileprefix);
	strcat(csvfile,"bitrate.csv\0");
	FILE* fd = fopen(csvfile,"a+");
	fprintf(fd,"%s,%d,%d,%f\n",filename,size,cf.nsegundos,(float)(8*size/cf.nsegundos)/1000);
	fclose(fd);
}