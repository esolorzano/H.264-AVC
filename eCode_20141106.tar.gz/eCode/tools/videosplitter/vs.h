/**
 *  @author Edwin Solorzano <solorzano.em@gmail.com>
 *  @file vs.h
 *  @date 2014-07-04
 *  @version 0.1.0
 */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <limits.h>
#include <math.h>
#include <time.h>

#include "../h264bitstream-0.1.10/bs.h"
#include "../h264bitstream-0.1.10/h264_stream.h"

#include "libs/common.h" //getPeriodTime(), calculateRate() & timeval_subtract()
#include "libs/ini.h" //init config file load
#include "libs/h264_gops.h"


#define STREAMSEG_SIZE	4*1024*1024
#define GOPBUFFER_SIZE	128*1024
/**Longitud del buffer que contiene un GOP */
#define MEANGOP_SIZE		GOPBUFFER_SIZE/2
/**Número de GOPs en un segundo de vídeo */
#define GOPSinSECOND		24

/**
 *  Estructura que contiene la configuración del divisor de streams H.264
 */
typedef struct
{
    /*@{*/
    const char* inFile;     /**<Nombre del fichero de configuración */
    const char* sourceH264; /**<Nombre del fichero que contiene el stream H.264 */
    const char* outpath;    /**<Ruta de la carpeta donde se guardarán los ficheros segmento H.264 */
    const char* fileprefix; /**<Prefijo del nombre de los ficheros segmento H.264 */
    int nsegundos;          /**<Duración de los ficheros segmento H.264 */
    const char* mediadesc;  /**<Nombre del fichero de descripción de los ficheros segmento H.264 */
    int debug;              /**<Bandera de depuración */
    /*@}*/
    
    // al agregar un parámetro aqui tambien se debe actualizar la funcion handler()
} config_vs_t; 

void createH264file(int size, uint8_t* buffer, int fileCounter, config_vs_t cf);
int setup(stream_read_status_t* sources_status, config_vs_t config);
int setdown(stream_read_status_t* sources_status);
static int handler(void* user, const char* section, const char* name, const char* value);
char* itoa(int val);
void createMediaDescriptionFile(config_vs_t config,int fileCounter);

void testSaveLocal(uint8_t* buffer, int size);
void recordBitrate(char* filename, int size, config_vs_t cf);
